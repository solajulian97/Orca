# CVP Qualified Volume Text Hover

Date: 2026-09-03

## Objective

Show concise Bid, Ask and Delta evidence when the pointer is over a threshold-qualified Volume-only row, without restoring clutter to the chart.

## Files Changed

- `Orca Trades/Working_Suite/Indicators/OrcaCandleVolumeProfile.cs`: conditional strict-side retention and qualified-row evidence lookup.
- `Orca Trades/Working_Suite/Indicators/OrcaCandleVolumeProfile.Rendering.cs`: Volume-row hit testing and concise tooltip.
- `tests/OrcaFootprint.PlatformCheck/Program.cs`: strict-evidence, qualification and tooltip contract guards.
- `docs/indicators/ORCA_CANDLE_VOLUME_PROFILE.md`: hover and unavailable-data contract.
- This handoff.

## Behavior And Settings

- No new user-facing setting. Hover is active when `Emphasize Volume Text by Delta` is active in Volume mode.
- Only rows meeting the existing absolute-delta and delta-percent thresholds open this tooltip.
- Available strict evidence displays two unlabeled lines: `N x N`, then `+/-N`, where the second line is strict Ask-minus-Bid delta.
- Unclassified volume is intentionally omitted from this compact inspection.
- When no strict side is available, the tooltip displays `N/A x N/A`, then `N/A`; it never reverse-engineers Bid/Ask from inferred delta.

## Series, Replay, Cache, Rendering And Performance

- Secondary series added or changed: none.
- Existing `AddDataSeries`, `OnMarketData`, `OnBarUpdate`, trade attribution and signed-delta classification are unchanged.
- While Volume text emphasis is active, the existing strict Bid/Ask/unclassified dictionaries are populated alongside the existing volume and inferred-delta dictionaries.
- Historical strict hover evidence follows the selected CVP trade source and its quote limitations. Enabling the feature requires a normal reload to rebuild already-processed bars.
- Tick Replay behavior and shared cache publication are unchanged; strict hover evidence remains instance-local and is not published.
- The mouse handler derives the visible candle, profile lane and compressed row from current chart geometry, then sums only that bar's matching row under the existing short lock.
- No hit-box collection, tooltip string, brush allocation, profile calculation or new synchronization wait was added to `OnRender`.
- The existing WPF tooltip and lifecycle hooks are reused. Handlers detach on termination.

## Validation Status

- Pure model fixtures: passed, 407 checks.
- Offline authored-source platform check: passed with zero errors. Strict map retention, threshold qualification, concise tooltip/N/A disclosure, converter placement, legacy contracts and 13 attribution fixtures passed.
- `git diff --check`: passed; Git reported only expected LF-to-CRLF working-copy notices.
- Targeted deployment: complete for exactly `OrcaCandleVolumeProfile.cs` and `OrcaCandleVolumeProfile.Rendering.cs`. Normalized authored/live parity passed for both. No core, mirror, unrelated indicator or Full_Suite file was copied. The first rendering deploy shorthand was rejected before copying because the script treated `.Rendering` as an extension; deployment succeeded with the exact `.cs` filename.
- Live generated-source platform check: passed with zero errors, including generated wrappers.
- Assembly generation: NinjaTrader produced nonzero Custom DLL/PDB files timestamped 2026-09-03 15:28:52. This does not prove successful assembly load.
- NinjaTrader F5 compile/load: pending.
- Manual chart validation: pending.
- Full_Suite eligibility: **No** until Julian confirms F5 and chart behavior.

## Manual Acceptance

- Reload NinjaScript with Volume mode and emphasis enabled so strict historical evidence is collected.
- Hover positive and negative qualified numbers; verify Bid, Ask and Delta reconcile.
- Hover a nonqualifying number and empty profile space; verify no tooltip remains open.
- Check a row with unclassified volume and confirm disclosure rather than false zero sides.
- Test both right- and left-facing Volume arrangements, dynamic aggregation, zoom, pan and DPI scaling.
- Confirm Enhanced Bid x Ask hover remains unchanged.

## Risks And Rollback

- Ordinary historical secondary ticks may lack trade-associated quotes, producing `N/A` or unclassified evidence even when inferred delta exists. Tick Replay/market-data provenance limitations remain visible rather than hidden.
- Mouse movement performs bounded work across one candle's row maps; manual utilization testing remains required on dense charts.
- Disable `Emphasize Volume Text by Delta` to remove both the emphasis and hover path.
