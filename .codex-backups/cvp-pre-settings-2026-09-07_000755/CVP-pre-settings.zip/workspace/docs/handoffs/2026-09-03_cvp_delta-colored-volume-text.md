# CVP Delta-Colored Volume Text

Date: 2026-09-03

## Objective

Add optional positive/negative delta coloring to volume numbers in the Candle Volume Profile's Volume-only display, with optional row delta-percentage intensity and no change to profile values or bars.

## Files Changed

- `Orca Trades/Working_Suite/Indicators/OrcaCandleVolumeProfile.cs`: settings, contextual visibility, matching-row delta access, brush selection and palette lifetime.
- `Orca Trades/Working_Suite/Indicators/OrcaFootprintCore.cs`: platform-independent absolute delta fraction helper.
- `tests/OrcaFootprint.Tests/Program.cs`: delta-fraction fixtures.
- `tests/OrcaFootprint.PlatformCheck/Program.cs`: defaults, generated-signature, aggregation and neutral-fallback guards.
- `docs/indicators/ORCA_CANDLE_VOLUME_PROFILE.md`: user-facing behavior contract.
- This handoff.

## Behavior And Settings

- Added `Color Volume Text by Delta`, default off and visible only when `Profile Display` is `Volume`.
- Added `Scale Color by Delta %`, default on and visible only while the main color toggle is enabled.
- Both are ordinary serialized public properties, not `NinjaScriptProperty` factory parameters.
- Positive and negative rows reuse the existing delta colors and opacity palette. Percentage intensity is `abs(row delta) / row volume`, clamped to 0-100%.
- Solid directional color is used when percentage scaling is off. Exact-zero or unavailable delta retains `Volume Text Color`.
- Volume-bar fill, text value, threshold, alignment, font sizing, POC and Value Area behavior are unchanged.
- The feature is inactive outside Volume-only display and remains independent from `Color Volume By Delta`.

## Data, Replay, Cache And Rendering

- Secondary series added or changed: none.
- `AddDataSeries`, `OnMarketData`, `OnBarUpdate`, trade attribution, classification and accepted volume are unchanged.
- Tick Replay and historical-load behavior are unchanged. The renderer reads the existing row delta map when text coloring needs it, even if volume-bar delta coloring is off.
- Shared profile publication and cache contracts are unchanged.
- Delta is aggregated with the same displayed compression as volume before selecting text color.
- Existing RenderTarget-owned delta brushes and palettes are reused. Palette retention now also covers active percentage-colored volume text; no per-row brush allocation was added.
- The established legacy renderer still performs its existing map copy and aggregation. This change adds one matching delta-map copy only when the opt-in text feature is active.

## Validation Status

- Pure model fixtures: passed, 405 checks. Added zero, positive, negative, full, clamped and zero-volume delta-fraction cases.
- Offline installed-platform semantic check: passed with zero errors against authored source. Converter placement, legacy defaults/contracts, contextual settings, matching-row delta use, neutral fallback and 13 attribution fixtures passed.
- `git diff --check`: passed; Git reported only expected LF-to-CRLF working-copy notices.
- Targeted deployment: complete for exactly `OrcaFootprintCore.cs` and `OrcaCandleVolumeProfile.cs`. Normalized authored/live parity passed for both files. No mirror, unrelated indicator or Full_Suite file was copied.
- Live generated-source semantic check: passed with zero errors, including generated wrappers.
- Assembly generation: NinjaTrader produced nonzero Custom DLL/PDB files timestamped 2026-09-03 14:37:11. This is not proof that the assembly loaded successfully.
- NinjaTrader explicit F5 compile/load: pending.
- Manual chart validation: pending.
- Full_Suite eligibility: **No** until Julian confirms F5 and chart behavior.

## Manual Acceptance

- In Volume mode, verify positive, negative, exact-zero and weak/strong delta rows with percentage scaling on.
- Turn percentage scaling off and verify solid red/green text.
- Turn the main toggle off and confirm the prior volume text color is restored.
- Confirm Volume + Delta, Delta, Bid x Ask and Off do not apply the feature.
- Confirm `Color Volume By Delta` independently changes bar fill without being required for text coloring.
- Check compressed rows, custom delta colors, dynamic text sizing, zoom, template save and workspace reload.

## Risks And Rollback

- Very low-volume rows can have 100% delta intensity; `Volume Text Min Threshold` remains the intended filter.
- Weak colors use the configured delta minimum opacity and should be checked against the selected chart/profile background.
- Disable `Color Volume Text by Delta` for immediate visual rollback. No data rebuild is required.
