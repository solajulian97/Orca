# CVP Thresholded Volume Text Emphasis

Date: 2026-09-03

## Objective

Replace the low-contrast continuous delta-opacity treatment for Volume-only numbers with readable neutral text and thresholded full-color emphasis.

## Files Changed

- `Orca Trades/Working_Suite/Indicators/OrcaCandleVolumeProfile.cs`: threshold settings, contextual visibility, full-opacity brushes and optional heavy text.
- `Orca Trades/Working_Suite/Indicators/OrcaFootprintCore.cs`: platform-independent dual-gate qualifier.
- `tests/OrcaFootprint.Tests/Program.cs`: threshold boundary fixtures.
- `tests/OrcaFootprint.PlatformCheck/Program.cs`: settings, rendering and compatibility guards.
- `docs/indicators/ORCA_CANDLE_VOLUME_PROFILE.md`: revised display contract.
- This handoff.

## Behavior And Settings

- The existing serialized `ColorVolumeTextByDelta` property is retained and relabeled `Emphasize Volume Text by Delta`; default remains off.
- Added `Minimum Absolute Delta`, default 150, and `Minimum Delta %`, default 15%.
- Added `Bold Qualified Text`, default on.
- The three dependent controls appear only in Volume mode while emphasis is enabled.
- The former `ScaleVolumeTextColorByDeltaPercent` property remains serialized and defaults true but is hidden and no longer affects rendering.
- A row must meet both thresholds. Nonqualifying, zero and unavailable delta use `Volume Text Color` at normal weight.
- Qualifying rows use the configured Positive/Negative Delta hue at full opacity and optionally a heavier cached format.
- Profile values, volume-bar fills, geometry, POC, Value Area, alignment and font sizing are unchanged.

## Series, Replay, Cache, Rendering And Performance

- Secondary series added or changed: none.
- `AddDataSeries`, `OnMarketData`, `OnBarUpdate`, accepted trades and classification are unchanged.
- Tick Replay and historical loading are unchanged.
- Shared profile publication/cache contracts are unchanged.
- Qualification uses matching display-compressed delta and volume rows.
- Two RenderTarget-owned solid text brushes are added and disposed/recreated with the existing resources. No per-row brush or text-format allocation is added; the existing emphasized format cache is reused.
- The opt-in renderer continues to copy the matching delta map only when this feature or volume-bar delta coloring requires it.

## Validation Status

- Pure model fixtures: passed, 407 checks. Exact threshold, positive/negative symmetry, single-gate rejection, zero volume and invalid threshold cases passed.
- Offline authored-source platform semantic check: passed with zero errors. Converter placement, legacy contracts/defaults, matching compressed-row delta access, threshold selection, heavier-format use and 13 attribution fixtures passed.
- `git diff --check`: passed; Git reported only expected LF-to-CRLF working-copy notices.
- Targeted deployment: complete for exactly `OrcaFootprintCore.cs` and `OrcaCandleVolumeProfile.cs`. Normalized authored/live parity passed for both; no mirror, unrelated indicator or Full_Suite file was copied.
- Live generated-source platform semantic check: passed with zero errors, including generated wrappers.
- Assembly generation: NinjaTrader produced nonzero Custom DLL/PDB files timestamped 2026-09-03 15:16:29. This does not prove successful assembly load.
- NinjaTrader explicit F5 compile/load: pending.
- Manual chart validation: pending.
- Full_Suite eligibility: **No** until Julian confirms F5 and chart behavior.

## Manual Acceptance

- Confirm ordinary numbers remain clearly readable in `Volume Text Color`.
- Verify positive and negative rows at, below and above both thresholds.
- Confirm a row passing only one threshold remains neutral.
- Toggle `Bold Qualified Text` and verify color remains while weight changes.
- Confirm custom Positive/Negative Delta colors are respected at full opacity.
- Confirm other profile modes and `Color Volume By Delta` remain independent.
- Save/reload a template that previously contained the old intensity setting and confirm no settings error.

## Risks And Rollback

- Absolute thresholds are instrument-sensitive; 150 is the requested starting point and should be tuned during chart validation.
- Dark custom delta hues can still reduce contrast despite full opacity.
- Disable `Emphasize Volume Text by Delta` for immediate visual rollback.
