# CVP Bid x Ask Full Candle Display

Date: 2026-09-01

## Objective

Make the actual candle as legible in Bid x Ask as it is in Volume + Delta, while clearly documenting why enhanced and normal Bid x Ask can look similar. Reuse the existing serialized scaffold property rather than add an overlapping toggle.

## Files Changed

- `Orca Trades/Working_Suite/Indicators/OrcaCandleVolumeProfile.cs`: normal Bid x Ask center reservation, foreground candle rendering, shared setting exposure and existing renderer lifecycle adjustment. Concurrent Instant Replay adapter work remains intact.
- `Orca Trades/Working_Suite/Indicators/OrcaCandleVolumeProfile.Rendering.cs`: enhanced center reservation, full colored candle resources/drawing and split Cluster/POC geometry.
- `tests/OrcaFootprint.PlatformCheck/Program.cs`: preserves the Volume/Delta branch while allowing the approved Bid x Ask geometry and guarding its center reservation.
- `docs/indicators/ORCA_CANDLE_VOLUME_PROFILE.md`: mode comparison and shared Candle Display contract.
- This handoff.

## Behavior And Settings

- Existing `FootprintScaffold` serialization remains unchanged. Its display label is now `Candle Display`; choices are Off, OHLC Spine, and Full Candle. The serialized enum member for Full Candle remains `OhlcSpineAndBody`, preserving restored values.
- Default remains OHLC Spine, so existing visuals do not silently switch.
- Full Candle reserves `CandleWidthPx + 2 * CandleProfileGapPx` within the existing total Bid x Ask width. It does not increase the profile envelope or overlap neighboring candles; each side receives the remaining half-width.
- Normal and enhanced Histogram draw Bid to the left edge of the lane and Ask to the right. Cluster splits its fill around the lane. POC outlines split around the lane. Bid/Ask text remains on its corresponding side.
- Full Candle draws the configured bullish/bearish body width and wick in front. Normal mode retains an active absorption body brush through the foreground redraw when one is already selected. Enhanced mode owns dedicated RenderTarget brushes and disposes/recreates them with its other target resources.
- Off and OHLC Spine remain available. Volume, Delta and Volume + Delta geometry is unchanged.

## Enhanced Versus Normal

- Normal is the established direct renderer: per-bar normalization and display-compressed rows from legacy strict maps.
- Enhanced uses typed evidence, immutable prepared snapshots, fixed analysis rows independent of zoom, four normalization scopes, explicit missing/unknown states, POC ties/provisional state, hover inspection and optional technical status.
- The Histogram silhouette is intentionally similar. The distinction is calculation stability, scaling, inspection and render preparation, not decorative styling.

## Series, Replay, Cache And Performance

- Secondary series added/changed: none. Existing Tick 1/Tick Replay source choice, `OnMarketData`, `OnBarUpdate`, attribution and historical loading are unchanged.
- Shared profile cache contract/publication: unchanged.
- Concurrent completed-bar Instant Replay adapter additions in the main source are preserved and not altered by this feature.
- Enhanced adds two RenderTarget-owned candle brushes per instance. Normal reuses its existing body/wick brushes. No profile aggregation, cache access, synchronization wait or managed allocation was added to enhanced `OnRender`.
- Normal render keeps its existing map-copy/aggregation behavior; this task only adjusts row geometry and the lifetime of an already allocated optional absorption brush.

## Validation And Status

- Pure model harness: 399 checks passed.
- Offline platform semantic check: zero errors. Volume/Delta render branch remains token-identical, accepted-trade/classifier/shared-publication contracts pass, normal Bid x Ask center reservation is guarded, enhanced render allocation/lock/cache guard passes, and 13 attribution fixtures pass.
- `git diff --check`: passed for code before final documentation.
- Targeted deployment: complete for exactly `OrcaCandleVolumeProfile.cs` and `OrcaCandleVolumeProfile.Rendering.cs`. Authored source/live parity passed for both; no core, mirror, unrelated indicator or Full_Suite file was copied.
- NinjaTrader compile evidence: automatic source watching regenerated nonzero Custom DLL/PDB files at 22:09:24. Offline semantic compilation of the live generated source reported zero errors and passed all guards. Explicit F5 was not sent.
- Manual chart validation: pending.
- Manual checks: normal/enhanced Histogram and Cluster; Off/Spine/Full Candle; bullish/bearish/doji; absorption-colored normal candle; narrow/wide spacing; Candle Width/Gap changes; POC; Bid/Ask labels; winner emphasis; 100-200% DPI.
- Full_Suite eligibility: **No** until Julian validates the chart and concurrent replay changes reach their own gate.

## Risks And Rollback

- At very narrow bar spacing, the bounded total profile width may leave little room after reserving the candle. Text can hide by measured fit, and side bars can become short; neighboring overlap is still prohibited.
- Cluster text omits its center `x` while Full Candle occupies the lane; Bid and Ask remain left/right. Off/Spine retain the separator.
- Select OHLC Spine to restore the prior Bid x Ask presentation, or disable Enhanced Footprint for the normal renderer. Roll back only this focused geometry/resource change; do not overwrite concurrent replay work.
