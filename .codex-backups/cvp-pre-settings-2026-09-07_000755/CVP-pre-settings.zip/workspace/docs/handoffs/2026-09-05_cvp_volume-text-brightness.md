# CVP Volume Text Brightness

## Objective

Add an optional volume-driven brightness hierarchy to the white volume-number column in `Volume + Delta` without changing profile calculations or delta presentation.

## Files Changed

- `Orca Trades/Working_Suite/Indicators/OrcaCandleVolumeProfile.cs`
- `Orca Trades/Working_Suite/Indicators/OrcaFootprintCore.cs`
- `tests/OrcaFootprint.Tests/Program.cs`
- `tests/OrcaFootprint.PlatformCheck/Program.cs`
- `docs/indicators/ORCA_CANDLE_VOLUME_PROFILE.md`
- `docs/handoffs/2026-09-05_cvp_volume-text-brightness.md`

## Behavior And Settings

- `Scale Volume Text Brightness`, default off, appears only for `Profile Display = Volume + Delta`.
- `Volume Text Minimum Brightness`, default 0.35, appears only when scaling is enabled.
- Each candle's largest displayed volume row uses the full configured Volume Text Color.
- Smaller displayed rows use a square-root volume ratio and fade toward the configured minimum, preserving readability.
- Delta text, volume bars, Volume-only delta emphasis, thresholds, and hover behavior are unchanged.

## Data, Replay, Cache, Rendering And Performance

- Secondary series added or changed: none.
- `AddDataSeries`, `OnMarketData`, calculation mode, Tick Replay behavior, historical loading, shared cache publication, and classification are unchanged.
- Scaling uses the existing per-candle aggregated `maxVol`; it adds no data copies or profile rebuilds.
- SharpDX brushes come from a RenderTarget-owned cached palette and are recreated/disposed with existing resources. No per-row brush allocation is added.
- The feature is presentation-only and responds to the displayed compression rows.

## Validation

- Pure model harness: passed, 411 checks.
- Authored platform semantic check: passed with 0 errors and 13 baseline fixtures.
- Targeted Working_Suite deployment: complete for `OrcaCandleVolumeProfile.cs` and `OrcaFootprintCore.cs`; authored source/live parity passed.
- Live generated-code semantic check: passed with 0 errors.
- NinjaTrader Custom DLL/PDB regeneration observed at 2026-09-05 13:35:18; this does not prove successful F5 load.
- NinjaTrader F5 compile: pending.
- Manual chart validation: pending. Verify a `Volume + Delta` chart with the feature off/on, custom Volume Text Color, 35% and alternate minima, multiple compression levels, and active-bar updates.

## Status And Promotion

- Known risk: per-candle normalization communicates local volume shape, not cross-candle absolute volume comparison.
- Full_Suite eligibility: no. Requires Julian's NinjaTrader F5 compile and manual visual acceptance.
