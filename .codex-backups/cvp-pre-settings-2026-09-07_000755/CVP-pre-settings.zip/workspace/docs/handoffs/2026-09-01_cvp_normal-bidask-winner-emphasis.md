# CVP Normal Bid x Ask Winner Emphasis

Date: 2026-09-01

## Objective

Extend the same strict same-row winner emphasis from Enhanced Footprint to the normal Bid x Ask renderer, preserving the newer Instant Replay adapter work already present in the main CVP source.

## Files Changed

- `Orca Trades/Working_Suite/Indicators/OrcaCandleVolumeProfile.cs`: normal Cluster/Histogram text weighting, cached winner formats and normal Bid x Ask settings visibility. Existing uncommitted Instant Replay additions were preserved.
- `tests/OrcaFootprint.PlatformCheck/Program.cs`: guards both normal text paths for the shared qualifier.
- `docs/indicators/ORCA_CANDLE_VOLUME_PROFILE.md`: shared-mode behavior documented while preserving the newer Instant Replay section.
- This handoff.

## Behavior And Settings

- `Emphasize Row Winner` and `Winner Ratio` are now visible when Profile Display is Bid x Ask whether Enhanced Footprint is on or off.
- Normal Histogram keeps Bid left and Ask right; only the qualifying side uses the heavier cached format.
- Normal Cluster keeps Bid, `x`, Ask reading order and independently weights the qualifying side.
- Qualification is unchanged: strict same-row Bid/Ask, dominant side strictly larger, ratio at or above the configured threshold, unopposed positive volume qualifies, ties/0 x 0 do not. Unclassified volume is excluded.
- Volume, Delta, Volume and Delta, colors, bar widths, POC, aggregation, values and enhanced hover are unchanged.

## Series, Replay, Cache, Rendering And Performance

- Secondary series added/changed: none. Tick Replay, Tick 1, `OnMarketData`, `OnBarUpdate`, historical load and shared publication are unchanged by this task.
- The concurrent completed-bar Instant Replay adapter currently present in the main source is preserved and not modified by this feature.
- No new cache/data service. The existing legacy text-format cache key now includes winner state in addition to font size and alignment. At most one additional reusable format per encountered size/alignment is created; there is no per-row `TextLayout` allocation.
- No calculation, accepted evidence, normalization or profile geometry changes.

## Validation And Status

- Pure model harness: 399 checks passed; shared winner boundary fixtures unchanged.
- Offline installed-platform semantic check: zero errors. Both normal Bid x Ask text methods call the shared qualifier; converter placement, legacy contracts, enhanced render guard and 13 attribution fixtures pass.
- `git diff --check`: passed for the focused source/test/documentation files.
- Targeted deployment: complete for only `OrcaCandleVolumeProfile.cs`; authored source/live parity passed. The live file already contained the same concurrent replay adapter before deployment.
- NinjaTrader compile evidence: the automatic source watcher regenerated nonzero `NinjaTrader.Custom.dll` and PDB files at 21:55:22. Offline semantic compilation of the live generated source reported zero errors and all platform guards passed. Explicit F5 was not sent.
- Manual validation: pending normal Histogram and Cluster checks at 1.5 and 2.0, both sides, zero opposing side, ties, multiple font weights and Enhanced Footprint toggle.
- Full_Suite eligibility: **No** until Julian validates chart behavior and the concurrent replay work reaches its own gate.

## Rollback And Risks

- Disable `Emphasize Row Winner` to restore uniform normal and enhanced Bid x Ask text weight.
- Cluster now draws its three text pieces separately to weight one side without allocating a unique layout per row. Validate narrow cells and large values for collision/clip behavior.
- Roll back only this focused text/settings change; do not remove or overwrite the concurrent Instant Replay adapter additions.
