# Orca Leg-to-Leg Reset Delta Aggregation

## Objective

Allow the live active-leg delta reset to use a fixed tick aggregation independent of the original full-leg Delta profile. Preserve the existing reset behavior and every full-leg calculation when the new option is disabled.

## Files Changed

- `Orca Trades/Working_Suite/Indicators/OrcaLegtoLegProfile.cs`
- `docs/handoffs/2026-08-23_orca-leg-to-leg_reset-aggregation.md`

`Orca Trades/Full_Suite` was not modified.

The target source file already contained unrelated uncommitted Orca work. This change was limited to the active-reset model, reset rendering selection, two settings, and this handoff.

## Behavior Added Or Changed

- The active reset can follow the existing full-leg Delta aggregation or use its own fixed tick aggregation.
- The default remains follow mode, preserving the current reset display after templates and workspaces reload.
- Independent mode can retain finer post-reset rows, such as a 4-tick reset beside an 8-tick full-leg Delta profile.
- Reset Only, Overlay, and Side-by-Side all use the selected reset aggregation for the reset dataset only.
- Full-leg Delta rows, full-leg Volume rows, POC, Value Area, statistics, placement, leg detection, reversal handling, hotkeys, and reset clearing behavior are unchanged.

To retain price detail below the full-leg compression, reset price rows now accumulate directly from the already-classified post-anchor trades. The reset does not reclassify trades, retain tick history, or modify the original full-leg map. Repeated Reset Now replaces the reset with a new empty reset map, and Clear Reset or leg reversal discards that map.

## User-Facing Settings

Under `Delta Reset`:

- `Use Separate Reset Aggregation`: default `False`.
  - Off: reset rows follow the full-leg Delta aggregation. If dynamic aggregation is enabled, the reset follows the current dynamic row size.
  - On: reset rows use the fixed setting below and do not change with the full-leg dynamic aggregation.
- `Reset Delta Aggregation (Ticks)`: default `4`, range `1` to `100`.
  - Used only when separate reset aggregation is enabled.

Both settings are NinjaScript properties and are eligible for normal template/workspace serialization. Runtime reset state remains ephemeral and is not serialized.

## Secondary Series Added Or Changed

None.

- `SecondaryTickSeries` still uses the existing hidden Tick 1 series.
- `TickReplayLastEvents` still consumes replayed Last events through `OnMarketData`.
- No Tick, Second, Bid, Ask, Volumetric, or custom series was added or changed.

## Tick Replay Implications

Tick Replay behavior is unchanged. Historical Last events can rebuild the original leg profiles but cannot create a manual reset anchor. After real-time transition, a manual reset uses the selected reset aggregation for new incoming classified trades.

On reload, workspace restore, indicator recreation, or NinjaTrader restart, the manual reset and its reset-only map are gone. The original leg profile remains eligible to rebuild through the existing configured source, including Tick Replay when selected.

## Historical-Load Implications

Historical leg detection, reversal buffering, full-leg Volume and Delta construction, completed-profile rendering, and statistics are unchanged. No historical reset map is created or reconstructed.

## Cache Implications

No shared cache, persisted cache, database, or historical-data cache was added or changed. The reset-only map is in-memory and scoped to one active reset in one indicator instance.

NinjaTrader must regenerate the live generated accessor/cache region after targeted deployment so both new NinjaScript properties participate in the live indicator cache key. The authored `Working_Suite` generated region was not hand-edited.

## Rendering Implications

- The full-leg dataset continues to use the existing `deltaCompTicks` selected by fixed or dynamic aggregation.
- In follow mode, reset rows use that same render aggregation.
- In separate mode, reset rows use `Reset Delta Aggregation (Ticks)` in all three reset display modes.
- Each dataset continues to scale its bar widths independently.
- `OnRender` receives a copied reset map snapshot and never traverses the mutable calculation map.
- The former full-map-minus-baseline reconstruction pass is no longer needed; reset rows are already post-anchor-only.

Finer reset aggregation can produce more visible rows and labels and therefore more render work. Chart pan, zoom, and high-density reset ranges require live validation.

## Performance Implications

- No active reset: no reset price-map work or memory is used, regardless of the settings.
- Active reset: each classified trade adds at most one constant-time update to the reset map plus the existing reset scalar updates.
- Reset action: creates an empty map instead of copying the current full-leg Delta map.
- Render: copies the reset map under the existing lock order, then uses the shared Delta row renderer. The prior baseline-subtraction dictionary pass was removed.
- Memory: proportional to post-reset price buckets only; finer aggregation can increase the number of buckets up to the number of traded price levels. No duplicate tick history or second classification engine exists.

The existing lock order remains leg lock first, reset lock second. Calculation and UI threads do not mutate render snapshots.

## Tests Performed

Completed local checks:

- Modern Roslyn whole-file syntax parse: zero errors.
- Roslyn semantic compilation of the authored region against installed NinjaTrader/WPF/SharpDX assemblies and the current Custom assembly: zero errors.
- Brace balance: 362 opening and 362 closing braces.
- Exactly one NinjaScript generated-code region remains.
- Targeted stale-reference check: no `BaselineDeltaByPrice` or `BuildResetDeltaMap` references remain.
- Aggregation model assertions passed:
  - inherited fixed aggregation matches the prior baseline-subtraction result;
  - inherited dynamic one-tick storage regroups to the same result;
  - a 4-tick reset retains more granular rows than an 8-tick reset/full profile for the test sequence;
  - aggregation preserves reset total Delta;
  - reset aggregation does not mutate the full-leg map.
- `git diff --check` passed for the target source; Git reported only the repository line-ending conversion warning.
- Targeted deployment with `deploy_orca.ps1 -Target OrcaLegtoLegProfile` succeeded.
- Normalized authored-region parity passed between `Working_Suite` and the live NinjaTrader source; both SHA-256 hashes are `D9C1279C448DF6E79FA82C2EBBF6D2BA1F3D918216C6ED2C7017C8C914F2042E`.
- The live NinjaTrader generated accessor/cache region contains `UseSeparateResetAggregation` and `ResetDeltaAggregationTicks` in its overload signatures and cache comparisons.

No NinjaTrader chart, Playback, Tick Replay, reconnect, or restart behavior is claimed as tested.

## Compile Status

The authored source passed local semantic compilation, targeted deployment is complete, and NinjaTrader regenerated the live property accessors. This is not a NinjaTrader F5 compile.

The Windows app-control approval timed out before any UI input was sent, so F5 was not pressed and no NinjaTrader compile result is claimed.

## Manual-Validation Status

Pending Julian's NinjaTrader validation after targeted deployment and F5:

1. Leave `Use Separate Reset Aggregation` off and verify reset rows match the full-leg fixed aggregation.
2. Enable dynamic aggregation with separate reset aggregation off; pan and zoom and verify both Delta datasets regroup together.
3. Set full-leg Delta to 8 ticks, enable separate reset aggregation at 4 ticks, trigger Reset Now, and verify the reset lane shows finer rows while the full-leg lane remains 8 ticks.
4. Change the custom reset value to 1, 2, 4, and 8 on separate reloads and reconcile row boundaries against known NQ trade prices.
5. Validate Reset Only, Overlay, and Side-by-Side with independent aggregation.
6. Clear, replace, and cross a leg reversal; verify only the reset map is discarded.
7. Run Playback and live data long enough to compare reset total Delta with the sum of its visible price rows.
8. Validate Tick Replay reload and NinjaTrader restart: reset is gone and the original leg profile rebuilds/remains.
9. Stress pan/zoom with a 1-tick reset over a wide active range and inspect Orca diagnostics for render pressure.

## Known Issues, Risks, And Follow-Up Work

- Finer aggregation increases reset row count, label density, render work, and reset-map memory.
- The fixed custom reset value intentionally overrides dynamic aggregation for the reset dataset; the full-leg dataset can remain dynamic independently.
- NinjaTrader hides/disables dependent properties inconsistently in the standard property grid. The tick value remains visible when the toggle is off, but its description states that it is inactive.
- NinjaTrader F5 and runtime validation remain required; live generated accessor inspection is complete.
- The original active-reset feature itself still has pending live, Playback, Tick Replay, reconnect, reload, and reversal validation from its earlier handoff.
- No commit was created because the modified indicator file already contains substantial unrelated uncommitted Orca work that must not be bundled into this change.

## Promotion Eligibility

Not eligible for promotion to `Full_Suite` until NinjaTrader F5 succeeds and Julian confirms live, Playback, Tick Replay, reload/restart, leg-transition, and rendering behavior.
