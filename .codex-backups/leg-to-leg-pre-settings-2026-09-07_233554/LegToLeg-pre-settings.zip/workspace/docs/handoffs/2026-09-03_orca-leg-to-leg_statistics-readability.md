# Orca Leg-to-Leg Statistics Readability

## Objective

Correct the compact active-profile statistics after live screenshot review: keep text visible beside the price scale, prevent reset/full-leg overlap, and improve statistics clarity without changing profile data or price-level labels.

## Files Changed

- `Orca Trades/Working_Suite/Indicators/OrcaLegtoLegProfile.cs`
- `docs/handoffs/2026-09-03_orca-leg-to-leg_statistics-readability.md`

`Orca Trades/Full_Suite` was not modified. The indicator source already contained substantial unrelated uncommitted work; this follow-up was limited to statistics layout, resources, and appearance properties.

## Behavior Added Or Changed

- Statistics are right-aligned to their profile edge using a text rectangle that extends safely to the left.
- The right edge is clamped four pixels inside the chart panel, so a profile beside the price scale no longer loses the right side of its statistics text.
- In Side-by-Side mode, reset status/statistics begin below any visible full-leg statistics row instead of drawing at the same vertical position.
- Statistics use a dedicated DirectWrite format rather than the price-level label format.
- Statistics vertical bounds are rounded to whole pixels.
- The existing compact tokens remain unchanged: `T`, `F`, and signed `%`, separated by pipes.
- The reset anchor status remains separate and uses the same readable statistics styling.

No Delta, Finish Delta, Delta Percent, aggregation, reversal, hotkey, or reset-lifecycle formula changed.

## User-Facing Settings

Added under `Text Appearance`:

- `Statistics Font Size`: default `12`, range `8` to `30`. This affects only full-leg statistics, reset statistics, reset anchor status, and short reset-action messages.
- `Statistics Text Color`: default `White`. This is independently brush-serialized and does not alter positive or negative price-level label colors.

Existing `Delta Label Font Size`, `Text Font Family`, and `Text Font Weight` continue to control or feed the established text system. The new statistics format uses the selected font family and weight at its independent size.

## Secondary Series Added Or Changed

None.

- The existing hidden Tick 1 series in `SecondaryTickSeries` mode is unchanged.
- `TickReplayLastEvents` behavior is unchanged.
- No Tick, Second, Bid, Ask, Volumetric, or custom series was added or changed.

## Tick Replay Implications

None. Tick Replay processing, historical full-leg reconstruction, live reset eligibility, and ephemeral reset behavior are unchanged.

## Historical-Load Implications

None. Historical leg detection, reversal buffering, delta accumulation, statistics accumulation, and completed-profile rendering are unchanged.

## Cache And Serialization Implications

- No market-data cache, shared cache, database, or persisted reset state changed.
- `Statistics Font Size` is a NinjaScript property and participates in generated indicator cache identity.
- `Statistics Text Color` uses the existing WPF brush string-serialization pattern.
- NinjaTrader regenerated the live accessor/cache region after targeted deployment; the authored Working_Suite generated region was not hand-edited.

## Rendering Implications

- `DrawStatisticsRow` now clamps the row's right anchor to the chart panel and uses all available space to the left for right-aligned no-wrap text.
- The background remains limited to the configured profile-lane width rather than covering the chart.
- Full-leg and reset information are vertically sequenced in every reset display mode.
- A separate persistent statistics `TextFormat` and render-target-bound text brush are created, reused, disposed, and rebuilt with the existing SharpDX lifecycle.
- The dedicated format defaults to 12 px and white; price-level Delta labels remain at their prior size and colors.

## Performance Implications

No profile calculation, cache access, synchronization, text measurement, historical scan, or model mutation was added to `OnRender`. The added work is constant-time rectangle arithmetic and one persistent text format/brush per indicator render target. No per-render DirectWrite resource allocation was introduced.

## Verification Performed

- Inspected both supplied NinjaTrader screenshots at original resolution.
- Modern Roslyn whole-file syntax parse: zero errors.
- Authored-region Roslyn semantic compilation against installed NinjaTrader, WPF, SharpDX, replay-core, and diagnostics contracts: zero errors. The offline harness substituted only the platform-generated ATR accessor and shared `VALineStyleEnum` dependency.
- Assertions passed for:
  - dedicated statistics text format;
  - trailing/right alignment;
  - chart-panel right-edge clamp;
  - whole-pixel vertical alignment;
  - Side-by-Side reset vertical continuation;
  - 12 px default statistics size;
  - white default statistics color;
  - brush serialization.
- Geometry model confirmed a lane extending beyond a 1306 px panel clamps to x=1302, four pixels inside the right edge.
- Brace balance passed at 388 opening and 388 closing braces.
- Exactly one NinjaScript generated-code region remains.
- `git diff --check` passed for the indicator source with only its existing LF-to-CRLF warning.
- Targeted deployment with `deploy_orca.ps1 -Target OrcaLegtoLegProfile` succeeded.
- Normalized authored-region source/live parity passed with SHA-256 `5C3485D202BFEE5C6C9FFCA9BB85BD857DEFAC4EBDB1CE116414AC4D226A190A`.
- Live source contains the new font, brush serialization, right alignment, and Side-by-Side continuation.
- Live generated-code inspection found `StatisticsFontSize` in the accessor/cache region.
- NinjaTrader regenerated `NinjaTrader.Custom.dll`, `.pdb`, and `.xml` at 2026-09-03 23:23:31 after deployment.

## NinjaTrader Compile Status

The source-watcher assembly artifacts regenerated after deployment, which is semantic-build evidence. An explicit NinjaScript Editor F5 compile was not performed because native Windows application control is unavailable in this task. Artifact generation is not being reported as explicit F5 or chart-load validation.

## Manual-Validation Status

Pending Julian's chart validation:

1. Press F5 and confirm no compiler errors.
2. Keep the active profile beside the price scale and confirm every statistics token is visible with a four-pixel right margin.
3. Trigger Side-by-Side reset with both full-leg and reset statistics enabled and confirm the datasets occupy separate rows with no overlap.
4. Check Reset Only and Overlay for the same vertical sequencing.
5. Confirm default 12 px white text is sharp enough on the production monitor and chart background.
6. Change `Statistics Font Size` and `Statistics Text Color`, reload the indicator/workspace, and confirm persistence.
7. Change the existing font family and weight and confirm both price-level labels and the dedicated statistics format rebuild correctly.
8. Clear/repeat a reset and cross a leg reversal; confirm only display geometry changed.

## Known Issues, Risks, And Follow-Up Work

- The text rectangle can extend left across unused chart space so the full string remains visible; it remains right-anchored to its associated profile edge.
- The lane-width background does not expand under text that is wider than the lane. This preserves the chart rather than painting a large opaque strip.
- The screenshots suggest 12 px white text should materially improve clarity, but only live chart inspection can establish the best size for Julian's monitor scaling.
- No live chart, Playback, Tick Replay, reconnect, reload, or restart behavior is claimed as tested in this pass.
- No commit was created because the target source remains part of a mixed dirty worktree.

## Promotion Eligibility

Not eligible for promotion to `Full_Suite` until NinjaTrader F5 succeeds and Julian confirms edge visibility, non-overlap, sharpness, settings persistence, and reset display behavior.
