# Orca Leg-to-Leg Active Delta Reset

## Objective

Add a live, DOM-style delta reset to the active Orca Leg-to-Leg profile without destroying or replacing the original full-leg volume or delta data.

The implemented V1 supports one ephemeral reset anchor. Side-by-Side is the default display and uses this left-to-right order with no default gap:

`[Reset Delta] [Full-Leg Delta] [Full-Leg Volume]`

The full-leg Delta and Volume lanes keep their existing location. Clearing the reset removes only the reset lane. Reversal to a new current leg also removes the reset.

## Files Changed

- `Orca Trades/Working_Suite/Indicators/OrcaLegtoLegProfile.cs`
- `docs/handoffs/2026-08-21_orca-leg-to-leg_active-delta-reset.md`

`Orca Trades/Full_Suite` was not modified.

## Existing Data Flow And Integration Points

The existing data flow remains intact:

1. `OnMarketData` receives Bid/Ask updates and, in `TickReplayLastEvents` mode, Last trades. The legacy source uses the hidden 1-tick series in `OnBarUpdate`.
2. `ProcessTradeEvent` validates and maps the trade time to the primary bar, then classifies signed volume from Bid/Ask with tick-direction fallback.
3. Both leg trackers receive the same classified trade. Each tracker maintains an extreme and a reversal buffer. On reversal, buffered trades from the prior extreme are replayed into the newly published leg.
4. `ProcessTickToLeg` updates compressed volume-by-price and delta-by-price maps.
5. `OnRender` snapshots leg maps under the leg lock, computes Volume POC/Value Area, dynamically regroups Delta rows, and renders the active profile at the configured right offset plus completed profiles at their leg start times.

The reset integrates at three narrow points:

- `ProcessTradeEvent` assigns a monotonic trade sequence before both trackers process the trade.
- The active tracker's existing `ProcessTickToLeg` path updates full-leg scalar statistics and, when a matching reset exists, only the reset cumulative extrema. Trade classification and price bucketing are not duplicated.
- `DrawLegProfiles` derives reset-relative price rows by subtracting the immutable anchor snapshot from the current full-leg Delta snapshot, then sends both datasets through the same Delta row renderer.

## Behavior Added

- One active reset anchor is allowed per indicator instance.
- Reset Now replaces an existing anchor if pressed repeatedly.
- The reset anchor captures the current active leg ID, market time, trade sequence, total volume, total Delta, and an immutable copy of Delta-by-price.
- Every trade fully processed before the `TriggerCustomEvent` reset callback belongs to the full-leg baseline. The first trade processed after that callback is the first post-reset trade.
- Resetting never deletes or mutates the full-leg maps.
- Clear Reset deletes only the reset state and immediately returns to the normal full-leg display.
- A current-leg reversal automatically clears the reset after the new leg has been fully backfilled and atomically published.
- Reset Now is rejected with chart feedback when the indicator is not in real-time state, `Show Delta` is disabled, or no active leg exists.
- Clear Reset is safe and reports `No active reset` when there is nothing to clear.
- Removing, disabling/reloading, or recalculating the indicator destroys the in-memory reset naturally. The original profile is rebuilt through its existing data source.
- A connection interruption that does not recreate the indicator keeps the in-memory reset. A reload/recreation during reconnect clears it.

## Display Modes

- **Reset Only:** hides full-leg Delta rows and renders reset Delta in the existing Delta lane. Full-leg Volume is unchanged.
- **Overlay:** renders full-leg Delta in the existing lane at the configured lower opacity, without its row labels, then renders reset Delta prominently on top.
- **Side-by-Side:** leaves full-leg Delta and Volume fixed and adds the reset Delta lane directly to the left. An optional nonnegative pixel gap can be configured; its default is zero.

Historical completed profiles do not participate in reset modes and retain the existing `Mirror Historical Profiles` behavior. Active profile orientation still follows `Show Delta` exactly as before.

## Statistics Semantics

Full-leg scalar statistics are accumulated alongside the existing full-leg maps. Reset scalar statistics begin at zero at the anchor.

- **Total Delta:** current cumulative signed trade volume for the selected dataset.
- **Finish Delta:** the existing Orca Time Statistics definition, `current delta - (current delta >= 0 ? maximum cumulative delta : minimum cumulative delta)`. For the reset dataset, maximum and minimum cumulative Delta are measured only after the reset anchor.
- **Delta Percent:** dataset Delta divided by dataset total trade volume, multiplied by 100. Reset volume is full-leg volume minus anchor-baseline volume.

Unclassified trade volume contributes to total volume but contributes zero to Delta, matching the existing classification path.

## User-Facing Settings

All settings are per indicator instance.

### Delta Reset

- `Enable Active Delta Reset`: default `False`.
- `Reset Display Mode`: default `Side-by-Side`.
- `Reset Now Hotkey`: default `Ctrl+Alt+R`.
- `Clear Reset Hotkey`: default `Ctrl+Alt+C`.
- `Full-Leg Overlay Opacity`: default `0.25`, range `0.05` to `1.0`.
- `Side-by-Side Gap (px)`: default `0`, range `0` to `100`.
- `Show Reset Status`: default `True`.

### Delta Reset Statistics

- `Show Full-Leg Total Delta`: default `False`.
- `Show Full-Leg Finish Delta`: default `False`.
- `Show Full-Leg Delta Percent`: default `False`.
- `Show Reset Total Delta`: default `True`.
- `Show Reset Finish Delta`: default `True`.
- `Show Reset Delta Percent`: default `True`.

With no active reset and all new full-leg statistics left at their defaults, rendering is the existing full-leg behavior.

## Hotkey Lifecycle And Conflict Protection

- Hotkeys are attached only when the feature is enabled and the indicator has a chart control.
- The handler is attached to the indicator's own `ChartControl`, so the chart surface must have keyboard focus; it is not a platform-global shortcut.
- Exact modifiers are required. Key repeat is ignored. Text box, password box, and combo-box focus suppresses the action.
- The WPF handler is stored and removed during `State.Terminated`.
- The UI event crosses to the NinjaScript processing thread with `TriggerCustomEvent` before model state changes.
- If Reset Now and Clear Reset use the same chord, no action is taken.
- If more than one enabled Orca Leg-to-Leg instance on the same chart owns the chord, no action is taken.
- NinjaTrader does not expose a complete global hotkey registry. Conflicts with unrelated third-party handlers cannot be detected in advance, so the feature is default-off and respects an already-handled WPF event.

## Secondary Series

No secondary series were added, removed, or changed.

- `SecondaryTickSeries` still adds the existing hidden Tick 1 series.
- `TickReplayLastEvents` still consumes replayed Last events through `OnMarketData`.
- No Bid, Ask, Second, Volumetric, or custom series was added.

## Tick Replay

Tick Replay continues to rebuild the normal full-leg profile when `TickReplayLastEvents` is selected. Reset commands are deliberately rejected during historical processing. Historical Last events never invent a manual reset anchor.

After a restart, workspace restore, chart reload, or indicator recalculation:

- the manually created reset is gone;
- the original leg profile is rebuilt from the configured historical/Tick Replay source as before.

Manual reset persistence and historical anchor placement remain future extensions.

## Historical Load

Historical leg detection, reversal buffering, Delta classification, full-leg profile construction, and completed-profile rendering are unchanged except for the new scalar statistics accumulated beside the maps. No historical reset is created or reconstructed.

## Serialization

User settings are NinjaScript properties and are eligible for normal template/workspace serialization. Runtime reset state is intentionally not serialized. There is no session ID, timestamp replay search, database record, or workspace payload for a manual reset.

## Cache

No shared cache, database, or historical-data cache was added or changed. NinjaTrader regenerated the live generated accessor/cache region after targeted deployment so the new NinjaScript properties are present in the live overload and cache key. The authored `Working_Suite` generated region was not hand-edited.

## Thread Safety

- Full-leg maps and scalar statistics are mutated under the existing per-leg lock.
- Reset state has a dedicated lock.
- Any operation requiring both locks always acquires the leg lock first and the reset lock second.
- A new current leg is built and reversal-buffer trades are replayed before the tracker publishes it, preventing Reset Now from anchoring a partially built leg.
- UI hotkeys do not directly mutate NinjaScript model state.
- `OnRender` reads copied maps and scalar snapshots; it does not mutate calculation collections or wait on the UI thread.

## Rendering

The existing Delta drawing loop was extracted into one reusable row renderer for full and reset datasets. Each dataset scales independently to its own maximum absolute Delta.

Side-by-Side and Overlay can draw two Delta datasets. Volume, POC, Value Area, completed-profile placement, right offset, and the fixed full-leg lane are unchanged. Statistics are compact top-of-panel rows inside their associated Delta lane. Short action feedback is drawn temporarily at the bottom of the original active Delta lane.

NinjaTrader buffers `OnRender`, so a hotkey result may appear on the next render frame rather than at the exact keyboard timestamp. The calculation anchor itself is established on the synchronized custom-event callback.

## Performance

- Per trade: existing map updates plus constant-time full-leg scalar updates; a matching active reset adds three constant-time scalar updates.
- Reset action: one Delta-by-price dictionary copy, proportional to the number of current-leg price rows.
- Render with an active reset: one full Delta snapshot, one baseline subtraction pass, and either one or two Delta draws depending on mode.
- Memory with a reset: one immutable baseline Delta dictionary plus small scalar state. There is no duplicate tick history and no second trade-classification engine.
- No full historical rebuild, cache read, allocation-heavy operation, dispatcher wait, or synchronization wait was added to the per-trade path or `OnRender`.

## Tests Performed

Completed static and model checks:

- Modern Roslyn full-file syntax parse: passed with zero syntax errors.
- Roslyn semantic compile of the authored region against installed NinjaTrader, WPF, and SharpDX assemblies: passed with zero errors.
- Reset model assertions: baseline subtraction, post-reset cumulative extrema/Finish Delta, and zero-gap Side-by-Side geometry passed.
- `git diff --check`: passed; Git reported only the repository line-ending conversion warning.
- Targeted deployment: `deploy_orca.ps1 -Target OrcaLegtoLegProfile` succeeded.
- Live authored-region parity: passed. Normalized source and live authored SHA-256 are both `6F00A8AFE1B872F840AEF853BC0BDC5D01CF8C533357F0BAD7547016A670839E`.
- Live generated-region inspection: the regenerated method signatures and cache comparisons include every new reset setting.

No NinjaTrader chart, Playback, reconnect, or Tick Replay behavior has been claimed as tested.

## Compile Status

Targeted source deployment is complete. A local semantic compile passed, but this is not a NinjaTrader F5 compile.

The Windows-control helper was not authorized to control NinjaTrader, and current NinjaTrader logs contain no post-deployment compile result. F5 compile remains pending Julian's confirmation.

## Manual Validation Status

Pending. Recommended validation matrix after F5 and an indicator reload:

1. Feature disabled: verify the existing active/historical profile is unchanged and default hotkeys do nothing.
2. Feature enabled, focused chart: press Reset Now and verify the first subsequent trade starts reset Delta from zero.
3. Side-by-Side: verify `[Reset][Full Delta][Volume]`, with the latter two lanes fixed before, during, and after reset.
4. Clear Reset: verify only the reset lane and reset statistics disappear.
5. Repeated Reset Now: verify the visible reset dataset returns to zero and begins from the newest anchor.
6. Reset Only and Overlay: verify full-leg Volume is unchanged; verify Overlay opacity and label priority.
7. Statistics: reconcile full/reset Total Delta, Finish Delta, and Delta Percent against a known trade sequence.
8. Leg reversal: verify reset clears once and the next leg is normal.
9. Invalid states: verify no-active-leg, historical state, `Show Delta = False`, key repeat, text focus, duplicate chords, and two enabled instances on one chart.
10. Secondary Tick source: validate live data, chart reload, reconnect without recreation, and reconnect with recreation.
11. Tick Replay Last Events: verify full profile reconstruction, no historical reset anchor, and reset availability only after real-time transition.
12. Playback: reset at a known playback event, pause/resume, clear, replace, cross a reversal, and compare the post-anchor rows/statistics to the event stream.
13. Workspace/NinjaTrader restart: verify reset is gone and the original full-leg profile rebuilds/remains according to the configured data source.
14. Pan/zoom and dynamic aggregation: verify both datasets regroup correctly without shifting the full-leg lane.
15. Remove/re-add and recompile lifecycle: verify no stale hotkey handler or reset survives.

## Acceptance Criteria

- With no active reset and new settings at defaults, existing full-leg and historical behavior is visually and numerically unchanged.
- Reset Now never modifies the original full-leg maps or scalar totals.
- Clear, reversal, reload, removal, and recalculation cannot leave a visible or callable stale reset.
- The reset includes no trade processed before the synchronized anchor callback and includes every qualifying trade processed afterward until clear/replacement/reversal.
- All three display modes preserve full-leg Volume and existing active placement.
- Full and reset statistics follow the definitions in this handoff.
- Hotkeys act only from the focused chart, ignore repeat/text entry, and fail closed for detected duplicate Orca bindings.
- Full historical/Tick Replay profile reconstruction succeeds without reconstructing a manual reset.
- No material render stalls or per-trade allocation increase is observed during Playback/live stress checks.

## Known Issues, Risks, And Follow-Up

- NinjaTrader F5 and live chart validation are still required.
- NinjaTrader has no public complete registry for all platform and third-party keyboard shortcuts; only same-chart Orca duplicate ownership and routed-event handling can be checked.
- Runtime reset state is intentionally ephemeral. Recovering an exact manual anchor after restart would require a separately approved persistence/replay design.
- Side-by-Side increases active profile width to the left and can overlap candles when Delta widths are large; the full-leg lane remains fixed by design.
- The target source file already contained unrelated uncommitted Orca work before this change. No commit was created because committing the file would bundle those unrelated edits.

## Promotion Eligibility

Not eligible for promotion to `Full_Suite` until NinjaTrader F5 succeeds and Julian confirms live, Playback, Tick Replay, reload, and leg-transition behavior.
