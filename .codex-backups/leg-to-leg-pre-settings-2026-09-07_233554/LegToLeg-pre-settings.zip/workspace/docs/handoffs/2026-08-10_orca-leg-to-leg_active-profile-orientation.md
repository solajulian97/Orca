# Orca Leg-to-Leg Active Profile Orientation

## Objective

Make the active Orca Leg-to-Leg profile orient independently from historical profiles:

- With Delta hidden, historical volume profiles face right while the active volume profile uses the price-scale edge as its spine and faces left toward the candles.
- With Delta shown, the active profile keeps Delta on the left and Volume on the right.

## Files Changed

- `Orca Trades/Working_Suite/Indicators/OrcaLegtoLegProfile.cs`
- `docs/handoffs/2026-08-10_orca-leg-to-leg_active-profile-orientation.md`

## Behavior Changed

- Active profile orientation is now automatic and based on whether Delta is visible for that profile.
- Active Volume-only profiles are mirrored so their spine stays at the configured right edge and their bars extend left.
- Active profiles with Delta visible retain the existing Delta-left and Volume-right arrangement.
- Historical profiles continue to use the existing `MirrorProfile` preference independently of the active profile.

No profile calculations, leg detection, POC/value-area calculations, colors, widths, labels, opacity, or active/historical data selection were changed.

## User-Facing Settings

- The display name of `Mirror Profile` is now `Mirror Historical Profiles`.
- Its backing property, default value, and serialization identity remain unchanged so existing templates and workspaces retain their value.
- The setting now explicitly controls historical profiles only; active orientation is automatic.

## Secondary Series

No secondary series were added, removed, or changed. Existing Tick, Bid, Ask, Last, Volumetric, and custom-series behavior is unchanged.

## Tick Replay

No Tick Replay requirements or behavior changed.

## Historical Load

Historical leg construction and load behavior are unchanged. Only the render orientation selected for completed profiles is affected by the existing historical mirror setting.

## Cache

No cache keys, cache reads, cache writes, or snapshot publication paths changed.

## Rendering

`DrawLegProfiles` now derives a local orientation for each rendered profile:

- Current + Delta hidden: mirrored.
- Current + Delta visible: not mirrored.
- Historical: follows `MirrorProfile`.

The local orientation is applied consistently to the spine, volume bars, value-area lines, Delta bars, and Delta labels. Existing chart/panel clipping remains unchanged.

## Performance

The change adds two local Boolean decisions per rendered profile and no new collections, allocations, synchronization, calculations, or data access. Expected performance impact is negligible.

## Tests Performed

Static checks completed:

- C# syntax parsed with Roslyn: zero syntax errors.
- Opening and closing brace counts match.
- Exactly one NinjaScript generated-code region remains.
- No draw-coordinate ternaries still use the global `MirrorProfile` value directly.
- Geometry matrix verified for historical/current and Delta hidden/visible combinations.
- `git diff --check` passed; Git reported only the repository's line-ending conversion warning.
- Targeted deployment completed with `deploy_orca.ps1 -Target OrcaLegtoLegProfile`.
- The authored source region matches the live NinjaTrader copy exactly (SHA-256 `C6FEBEFF237F91146962D0C509686E2EB0BBF510C5E52A77F230D69EF624D4EC`).

NinjaTrader chart tests have not yet been performed.

## Compile Status

Deployed to NinjaTrader. F5 compile is pending Julian's confirmation.

## Manual Validation Status

Pending. Validate both `Show Delta` states, the unchecked and checked historical mirror setting, and chart pan/zoom behavior.

## Known Issues, Risks, And Follow-Up

- The optional current-leg box geometry was not changed because this request concerns profile orientation only.
- Existing templates keep their historical mirror value, but the setting label changes after a successful NinjaTrader compile/reload.
- Runtime behavior still requires F5 compile and chart validation.

## Promotion Eligibility

Not eligible for promotion to `Full_Suite` until NinjaTrader compiles successfully and Julian confirms live behavior.
