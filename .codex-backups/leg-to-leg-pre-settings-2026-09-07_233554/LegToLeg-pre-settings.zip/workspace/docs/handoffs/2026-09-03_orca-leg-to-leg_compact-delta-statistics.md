# Orca Leg-to-Leg Compact Delta Statistics

## Objective

Clean up the active Leg-to-Leg Delta statistics so each dataset uses one compact horizontal row inspired by the supplied reference, without changing profile calculations, reset behavior, or placement.

## Files Changed

- `Orca Trades/Working_Suite/Indicators/OrcaLegtoLegProfile.cs`
- `docs/handoffs/2026-09-03_orca-leg-to-leg_compact-delta-statistics.md`

`Orca Trades/Full_Suite` was not modified. The indicator source already contained substantial unrelated uncommitted work; this change was limited to statistics text construction and text wrapping.

## Behavior Added, Changed, Or Removed

- Full-leg statistics no longer draw the `FULL LEG` heading.
- Enabled statistics for each dataset now draw on one pipe-separated row instead of separate stacked rows.
- Total Delta is abbreviated as `T`.
- Finish Delta is abbreviated as `F`.
- Delta Percent is shown as a signed percentage value with only the `%` suffix.
- Example with all fields enabled: `T +570 | F -120 | +8.4%`.
- The active reset anchor status, such as `RESET 09:42:15`, remains a separate row so the manual anchor is still identifiable.
- Text wrapping is disabled for the shared Leg-to-Leg text format so a statistics strip remains a single horizontal line.

The existing statistic formulas and independent full-leg/reset visibility switches are unchanged.

## User-Facing Settings

No settings were added, removed, renamed, or re-ordered. Existing full-leg and reset statistic visibility properties continue to control which tokens appear in each horizontal row.

## Secondary Series Added Or Changed

None.

- The existing hidden Tick 1 series in `SecondaryTickSeries` mode is unchanged.
- `TickReplayLastEvents` remains unchanged.
- No Tick, Second, Bid, Ask, Volumetric, or custom series was added or changed.

## Tick Replay Implications

None. Tick Replay input, trade classification, leg construction, reset eligibility, reset ephemerality, and historical reconstruction are unchanged. This is a render-text-only change.

## Historical-Load Implications

None. Historical leg detection, reversal buffering, price maps, statistics accumulation, and completed-profile rendering are unchanged.

## Cache Implications

None. No shared cache, local trade cache, persistence format, generated property accessor, or NinjaScript cache key changed.

## Rendering Implications

- A full-leg statistics dataset now performs one statistics-row draw instead of a heading plus up to three value rows.
- A reset dataset now performs one compact value-row draw instead of up to three value rows; its optional reset-anchor row remains separate.
- Existing lane coordinates, background brush, centering, font family, font weight, font size, opacity, and display-mode placement are preserved.
- Reset Only, Overlay, and Side-by-Side continue to use their existing lane placement.
- The compact row is intentionally no-wrap. Very narrow configured Delta profile widths should be checked for clipping during manual validation.

## Performance Implications

No profile/model work, cache reads, historical scans, or synchronization was added to `OnRender`. The change assembles at most three short tokens and reduces the number of statistics rectangles and text draw calls. Delta rows and their existing text-width cache are unchanged.

## Verification Performed

- Inspected both supplied reference screenshots at original resolution.
- Modern Roslyn whole-file syntax parse: zero errors.
- Authored-region Roslyn semantic compilation against the installed NinjaTrader, WPF, SharpDX, replay-core, and diagnostics contracts: zero errors. The offline harness substituted only the platform-generated ATR accessor and the shared `VALineStyleEnum` dependency.
- Formatter model assertions passed for:
  - `T +570 | F -120 | +8.4%`
  - Total-only negative Delta.
  - Finish-only zero Delta.
  - Percent-only negative Delta.
- Source assertions confirmed the old `FULL LEG`, `Total`, `Finish`, and `Delta %` render strings are absent from the statistics methods.
- Source assertions confirmed `T`, `F`, pipe separation, percentage suffix, and no-wrap formatting are present.
- Brace balance passed at 382 opening and 382 closing braces.
- Exactly one NinjaScript generated-code region remains.
- `git diff --check` passed for the indicator source; Git reported only its existing LF-to-CRLF conversion warning.
- Targeted deployment with `deploy_orca.ps1 -Target OrcaLegtoLegProfile` succeeded.
- Normalized authored-region source/live parity passed with SHA-256 `DDAC312FFDF92DFC3AA2C20415FAB3D51FFE7FE7A53FE68068C28C02FFDDE33A`.
- The live source contains the compact tokens and no-wrap setting and no longer contains the full-leg statistics heading.
- NinjaTrader regenerated `NinjaTrader.Custom.dll`, `.pdb`, and `.xml` at 2026-09-03 15:34:28 after deployment.

## NinjaTrader Compile Status

The source-watcher assembly artifacts regenerated after deployment, which is semantic-build evidence. An explicit NinjaScript Editor F5 compile was not performed because the available computer-control surface exposed no native Windows applications. Do not treat artifact generation as an explicit F5 or assembly-load validation.

## Manual-Validation Status

Pending Julian's NinjaTrader chart validation:

1. Press F5 in the NinjaScript Editor and confirm no compiler errors.
2. With all three full-leg statistics enabled, confirm one row reads in the form `T ... | F ... | ...%` and no `FULL LEG` heading appears.
3. Trigger an active reset and confirm its optional `RESET HH:mm:ss` row remains, followed by one compact reset-statistics row.
4. Toggle each full-leg and reset statistic independently and confirm separators appear only between visible values.
5. Check Reset Only, Overlay, and Side-by-Side modes at the actual configured Delta widths for clipping.
6. Confirm changing font family, weight, and size preserves a single horizontal row.
7. Confirm clear, repeated reset, reversal, reload, Playback, live data, and Tick Replay behavior remains unchanged.

## Known Issues, Risks, And Follow-Up Work

- A compact no-wrap row can clip when the configured Delta profile width is too narrow for the selected font and enabled values. Manual validation should establish whether an adaptive statistics width or dedicated smaller statistics font is desirable.
- No live chart, Playback, Tick Replay, reconnect, reload, or restart behavior is claimed as tested in this pass.
- The target indicator remains part of a mixed dirty worktree. No commit was created because committing the file would bundle unrelated work.

## Promotion Eligibility

Not eligible for promotion to `Full_Suite` until NinjaTrader F5 succeeds and Julian confirms the compact text in the relevant display modes and widths.
