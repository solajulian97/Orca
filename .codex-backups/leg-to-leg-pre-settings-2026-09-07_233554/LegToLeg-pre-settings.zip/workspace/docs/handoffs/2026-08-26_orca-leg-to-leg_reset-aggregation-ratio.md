# Orca Leg-to-Leg Reset Aggregation Ratio

## Objective

Add a ratio-based aggregation mode for the live active-leg Delta reset while preserving the existing Follow Full Leg and Fixed Ticks behaviors and leaving the original full-leg profile untouched.

Ratio mode resolves the reset row size as:

`max(1, ceiling(rendered full-leg aggregation ticks × configured ratio))`

## Files Changed

- `Orca Trades/Working_Suite/Indicators/OrcaLegtoLegProfile.cs`
- `docs/handoffs/2026-08-26_orca-leg-to-leg_reset-aggregation-ratio.md`

`Orca Trades/Full_Suite` was not modified.

The indicator already contained substantial unrelated uncommitted Orca work. This change is limited to reset aggregation selection, compatibility, ratio calculation, and documentation.

## Behavior Added Or Changed

- Reset aggregation now has three modes:
  - Follow Full Leg uses the full-leg aggregation currently being rendered.
  - Fixed Ticks preserves the existing independent fixed-tick reset behavior.
  - Full-Leg Ratio multiplies the rendered full-leg aggregation by the configured ratio and rounds upward.
- Ratio examples: 16 × 0.50 = 8, 20 × 0.50 = 10, 21 × 0.50 = 11, and 10 × 0.30 = 3.
- Ratio mode follows dynamic full-leg aggregation after its existing clamp and hysteresis decisions, so reset rows regroup as chart zoom changes.
- A minimum of one tick is enforced.
- Reset Only, Overlay, and Side-by-Side all use the same resolved reset aggregation.
- No on-chart aggregation label was added.

Full-leg Delta and Volume maps, scalar statistics, POC, Value Area, placement, leg detection, reversal buffering, reset/clear hotkeys, reset lifecycle, completed profiles, and historical behavior are unchanged.

## User-Facing Settings

Under `Delta Reset`:

- `Reset Aggregation Mode`: default `Follow Full Leg`.
  - `Follow Full Leg`
  - `Fixed Ticks`
  - `Full-Leg Ratio`
- `Reset Delta Aggregation (Ticks)`: existing default `4`, range `1` to `100`; used only by Fixed Ticks.
- `Reset Aggregation Ratio`: default `0.50`, range `0.05` to `1.00`; used only by Full-Leg Ratio.

The former `Use Separate Reset Aggregation` property is hidden but retained as a NinjaScript compatibility bridge:

- Existing `False` values map to Follow Full Leg.
- Existing `True` values map to Fixed Ticks.
- A newly serialized Ratio mode is not overwritten by the compatibility property regardless of property load order.

Inactive tick and ratio fields remain visible in NinjaTrader's standard property grid; their descriptions identify the mode that uses them.

## Secondary Series Added Or Changed

None.

- `SecondaryTickSeries` still uses the existing hidden Tick 1 series.
- `TickReplayLastEvents` still consumes replayed Last events through `OnMarketData`.
- No Tick, Second, Bid, Ask, Volumetric, or custom series was added or changed.

## Tick Replay Implications

Tick Replay behavior is unchanged. Historical events can rebuild the normal full-leg profile but cannot create a manual reset anchor. Ratio aggregation begins only after a valid live reset and uses the same already-classified post-anchor trades as the other reset modes.

After reload, workspace restore, indicator recreation, or NinjaTrader restart, the manual reset remains intentionally absent while the original leg profile rebuilds through the configured source.

## Historical-Load Implications

Historical leg construction, reversal logic, full-leg aggregation, completed-profile rendering, and statistics are unchanged. No historical ratio reset is created or reconstructed.

## Cache Implications

No shared cache, persisted cache, database, or historical-data cache was added or changed. The reset map remains in-memory and scoped to one active reset in one indicator instance.

NinjaTrader must regenerate the live generated accessor/cache region after deployment so the aggregation enum and ratio participate in indicator cache identity. The authored `Working_Suite` generated region was not hand-edited.

## Rendering Implications

- The full-leg renderer continues to resolve fixed or dynamic `deltaCompTicks` exactly as before.
- The reset resolver receives that final rendered value.
- Ratio mode applies decimal-safe ceiling rounding to avoid binary floating-point values incorrectly pushing exact integer products to the next tick.
- Ratio-mode reset trades are stored at one-tick resolution so all post-anchor data can be regrouped when dynamic aggregation changes.
- `OnRender` continues to read copied snapshots and uses the existing shared Delta-row renderer for all three display modes.

## Performance Implications

- Follow and Fixed modes retain their existing reset-map storage resolution and per-trade work.
- Ratio mode adds no new classification path; it changes only the bucket size used for the existing reset map.
- One matching active-reset trade still performs one constant-time reset-map update.
- Ratio mode can retain more reset buckets than Fixed mode because it stores post-anchor Delta at one-tick resolution. Memory remains proportional to traded post-reset price levels, not tick count.
- Dynamic regrouping uses the existing render grouping pass. Finer ratios may increase visible rows, labels, and render work.
- No additional series, cache reads, historical rebuilds, tick history, timers, or dispatcher work was added.

## Tests Performed

Completed local checks:

- Modern Roslyn whole-file syntax parse: zero errors.
- Roslyn semantic compilation of the authored region against installed NinjaTrader, WPF, SharpDX, and current Custom assemblies: zero errors.
- Brace balance: 368 opening and 368 closing braces.
- Exactly one NinjaScript generated-code region remains.
- The legacy setting has no visible `Display` attribute and the new enum and ratio properties each occur once.
- Ratio arithmetic assertions passed for 16×0.5, 20×0.5, 21×0.5, 10×0.3, 11×0.3, 10×0.4, ratio 1.0, and one-tick minimum cases.
- Decimal conversion preserved exact-integer results such as 10×0.3 = 3 instead of incorrectly rounding to 4.
- Dynamic regroup assertions passed for full-leg aggregation values 16, 20, and 21; each regroup preserved the reset Delta total.
- Legacy migration assertions passed for old False→Follow, old True→Fixed, and new Ratio mode surviving the compatibility setter.
- `git diff --check` passed for the target source; Git reported only the repository line-ending conversion warning.
- Targeted deployment with `deploy_orca.ps1 -Target OrcaLegtoLegProfile` succeeded.
- Normalized authored-region parity passed between `Working_Suite` and the live NinjaTrader source; both SHA-256 hashes are `43A8314DC3410FD58C869BEDCB8C047167DD618B8DC2B48CD18D2644AB6E3A7C`.
- Live generated-code inspection passed: the overload signatures and cache comparisons contain `ResetAggregationMode`, `ResetDeltaAggregationTicks`, `ResetAggregationRatio`, and the hidden `UseSeparateResetAggregation` compatibility property.

No NinjaTrader chart, Playback, Tick Replay, reconnect, or restart behavior is claimed as tested yet.

## Compile Status

The authored source passed local semantic compilation. Targeted deployment and live generated-accessor inspection are complete. This is not a NinjaTrader F5 compile.

Windows app control explicitly denied access to NinjaTrader before window activation, so no F5 input was sent and no NinjaTrader compile result is claimed.

## Manual-Validation Status

Pending Julian's validation after targeted deployment and NinjaTrader F5:

1. Verify Follow Full Leg matches current fixed and dynamic full-leg rows.
2. Verify Fixed Ticks preserves the current independent reset behavior.
3. With full-leg aggregation 16 and ratio 0.50, verify reset aggregation 8.
4. Repeat with 20→10, 21→11, 10×0.30→3, and 11×0.30→4.
5. In dynamic mode, zoom through multiple full-leg aggregation values and verify the active reset regroups without changing its total Delta.
6. Validate Reset Only, Overlay, and Side-by-Side.
7. Replace and clear the reset, cross a leg reversal, reload/remove the indicator, and verify no stale reset remains.
8. Load templates saved with the old separate-aggregation toggle set both False and True.
9. Validate live data, Playback, Tick Replay real-time transition, reconnect, workspace restore, and NinjaTrader restart.
10. Stress a 0.05 ratio over a wide post-reset price range and inspect Orca render diagnostics.

## Known Issues, Risks, And Follow-Up Work

- Finer ratios can increase reset-map memory, visible row count, label density, and render time.
- NinjaTrader's standard property grid does not dynamically hide inactive settings in this implementation.
- Runtime reset state remains intentionally ephemeral.
- NinjaTrader F5 and runtime validation remain required.
- No commit should be created from the current mixed indicator diff because doing so would bundle unrelated uncommitted work.

## Promotion Eligibility

Not eligible for promotion to `Full_Suite` until NinjaTrader F5 succeeds and Julian confirms live, Playback, Tick Replay, reload/restart, template migration, leg-transition, and rendering behavior.
