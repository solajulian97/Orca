using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Reflection;

string suite = Path.Combine(Directory.GetCurrentDirectory(), "Orca Trades/Working_Suite/Indicators");
var trees = new[] { "OrcaStepProfile.cs", "OrcaDiagnosticsCore.cs" }.Select(f => CSharpSyntaxTree.ParseText(
    File.ReadAllText(Path.Combine(suite, f)).Split("#region NinjaScript generated code")[0],
    new CSharpParseOptions(LanguageVersion.CSharp7_3), f)).ToArray();
string framework = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Microsoft.NET/Framework64/v4.0.30319");
string platform = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "NinjaTrader 8/bin");
var paths = new List<string>();
foreach (string name in new[] { "mscorlib", "System", "System.Core", "System.Xml", "System.ComponentModel.DataAnnotations", "System.Xaml", "System.Data" })
    paths.Add(Path.Combine(framework, name + ".dll"));
foreach (string name in new[] { "WindowsBase", "PresentationCore", "PresentationFramework" }) paths.Add(Path.Combine(framework, "WPF", name + ".dll"));
foreach (string name in new[] { "NinjaTrader.Core", "NinjaTrader.Gui", "SharpDX", "SharpDX.Direct2D1", "SharpDX.DXGI" }) paths.Add(Path.Combine(platform, name + ".dll"));
paths.Add(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "NinjaTrader 8/bin/Custom/NinjaTrader.Custom.dll"));
var compilation = CSharpCompilation.Create("StepOfflineCheck", trees, paths.Select(p => MetadataReference.CreateFromFile(p)), new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary));
var errors = compilation.GetDiagnostics().Where(d => d.Severity == DiagnosticSeverity.Error).ToArray();
foreach (var error in errors) Console.WriteLine(error);
Console.WriteLine("Offline Step Profile semantic check: " + errors.Length + " errors. F5/runtime remain separate.");
if (errors.Length != 0) return 1;

// Execute the authored label decision, including the active-profile bypass.
var root = trees[0].GetRoot();
var draw = root.DescendantNodes().OfType<MethodDeclarationSyntax>().Single(m => m.Identifier.Text == "DrawBlockDelta");
var initial = draw.DescendantNodes().OfType<LocalDeclarationStatementSyntax>().Single(s => s.Declaration.Variables.Any(v => v.Identifier.Text == "showRowText"));
var filter = draw.DescendantNodes().OfType<IfStatementSyntax>().Single(s => s.Condition.ToString().Contains("HistoricalDeltaTextMode !="));
var mode = root.DescendantNodes().OfType<EnumDeclarationSyntax>().Single(e => e.Identifier.Text == "StepHistoricalDeltaTextMode");
string fixture = "using System; using System.Collections.Generic; " + mode + @"
public class Fixture {
 public static bool Check(bool isActiveProfile, int modeValue, bool ShowDeltaText, long value, float height, float historicalTextBarSpacing, int HistoricalDeltaTextMinRowHeight, int HistoricalDeltaTextMinBarSpacing) {
 var HistoricalDeltaTextMode = (StepHistoricalDeltaTextMode)modeValue;
 int DeltaTextMinThreshold = 10, HistoricalDeltaTextMinValue = 500;
 var rect = new { Height = height }; var kvp = new KeyValuePair<double,long>(0, value);
 " + initial + filter + " return showRowText; } }";
var refs = ((string)AppContext.GetData("TRUSTED_PLATFORM_ASSEMBLIES")!).Split(Path.PathSeparator).Select(p => MetadataReference.CreateFromFile(p));
var model = CSharpCompilation.Create("StepFilterFixture", new[] { CSharpSyntaxTree.ParseText(fixture) }, refs, new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary));
using var stream = new MemoryStream();
var result = model.Emit(stream);
if (!result.Success) throw new Exception(string.Join("\n", result.Diagnostics));
var check = Assembly.Load(stream.ToArray()).GetType("Fixture")!.GetMethod("Check")!;
var cases = new[] {
 (false,0,true,10L,6f,1f,true), (false,0,false,1000L,20f,20f,false),
 (false,1,false,500L,12f,8f,true), (false,1,true,-500L,12f,8f,true),
 (false,1,true,499L,12f,8f,false), (false,1,true,500L,11f,8f,false),
 (false,1,true,500L,12f,7f,false), (false,2,true,9999L,30f,30f,false),
 (false,3,true,9999L,30f,30f,false), (true,2,true,10L,6f,1f,true),
 (true,1,false,9999L,30f,30f,false)
};
foreach (var c in cases)
 if ((bool)check.Invoke(null, new object[] { c.Item1,c.Item2,c.Item3,c.Item4,c.Item5,c.Item6,12,8 })! != c.Item7)
  throw new Exception("Label filter failed: " + c);
Console.WriteLine("PASS: 11 production-expression filter cases, including cutoff equality, signed magnitude, global inheritance, hover-only, hidden, and active bypass.");
foreach (long value in new[] { 500L, -500L, 2000L })
 if (!(bool)check.Invoke(null, new object[] { false,1,false,value,1f,0f,0,0 })!)
  throw new Exception("Zero zoom cutoffs should allow magnitude >= 500");
Console.WriteLine("PASS: 3 zero-cutoff cases allow labels on one-pixel rows with zero bar spacing.");
return 0;
