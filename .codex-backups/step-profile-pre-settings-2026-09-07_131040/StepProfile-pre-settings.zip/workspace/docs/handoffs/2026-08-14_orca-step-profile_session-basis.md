# Orca Step Profile Session Basis

## Objective

Add `Session` as a third Step Profile basis beside `Time` and `Volume Amount`, with either two daily profiles (Overnight/RTH) or three daily profiles (Asian/London/New York).

## Files changed

- `Orca Trades/Working_Suite/Indicators/OrcaStepProfile.cs`
- `docs/handoffs/2026-08-14_orca-step-profile_session-basis.md`

## Behavior added, changed, or removed

- Added `Session` to the Step Basis dropdown.
- Added `Overnight / RTH` session construction:
  - Overnight: `[6:00 PM, 9:30 AM)`
  - RTH: `[9:30 AM, RTH End Time)`
- Added `Asian / London / New York` session construction:
  - Asian: `[6:00 PM, 3:00 AM)`
  - London: `[3:00 AM, 9:30 AM)`
  - New York: `[9:30 AM, RTH End Time)`
- Session boundaries use Eastern-aligned chart timestamps. The existing `RTH End Time` setting defines market close and defaults to 4:00 PM.
- The post-close-to-6:00 PM interval is excluded from Session mode.
- `RTH Only` is ignored in Session mode so it cannot remove Overnight, Asian, or London data. It remains unchanged for Time and Volume modes.
- A completed RTH/New York block is finalized after the first post-close tick. An empty next-session placeholder keeps that completed block on the historical rendering path until the next session begins.
- No behavior was removed from Time or Volume modes.

## User-facing settings

- Added `Session` to `Step Basis`.
- Added `Session Configuration` with:
  - `Overnight / RTH` (default)
  - `Asian / London / New York`
- Clarified that `RTH Start Time` applies to Time and Volume modes; Session mode uses a fixed 9:30 AM New York open.
- Clarified that `RTH End Time` defines the RTH close and New York session end.

## Secondary series

- No secondary series were added or changed.
- The indicator continues to use its existing hidden 1-tick Last series (`AddDataSeries(BarsPeriodType.Tick, 1)`).
- No Bid, Ask, Second, Volumetric, or custom series were added.

## Tick Replay implications

- Tick Replay requirements are unchanged.
- Session profiles consume the same hidden historical/live tick stream as existing Step Profile modes.

## Historical-load implications

- Historical session profiles rebuild from the loaded hidden tick series.
- Results depend on the chart Trading Hours template containing the requested Overnight/Asian/London periods and on available historical tick data.
- A chart template that omits overnight data cannot reconstruct omitted session profiles.

## Cache implications

- No shared cache was added or changed.
- Session membership is resolved with fixed timestamp comparisons in the existing tick path.

## Rendering implications

- No profile drawing or SharpDX rendering logic was added or changed for this feature.
- Session blocks reuse the existing active and historical profile renderer.
- The empty post-close placeholder prevents a completed RTH/New York block from continuing to render as the active right-edge profile when post-close ticks are available.

## Performance implications

- No new market-data subscription or secondary series was added.
- Per-tick session routing is constant-time and uses fixed `DateTime` comparisons.
- New `StepBlock` allocations occur only at session boundaries and when the post-close placeholder is created.
- No calculation, cache access, synchronization wait, or collection mutation was added to `OnRender`.

## Tests performed

- `git diff --check` passed for `OrcaStepProfile.cs` (line-ending warning only).
- Static source checks confirmed one Session enum member, one Session Configuration property/default, one window resolver, one `AddDataSeries` declaration, and one generated-code region.
- Boundary matrix passed for both configurations:
  - 5:59:59 PM excluded
  - 6:00 PM starts Overnight or Asian
  - 2:59:59 AM remains Overnight or Asian
  - 3:00 AM starts London in three-session mode
  - 9:29:59 AM remains Overnight or London
  - 9:30 AM starts RTH or New York
  - 3:59:59 PM remains RTH or New York with the default close
  - 4:00 PM is excluded with the default close

## Compile status

- NinjaTrader F5 compile is pending.
- The Working_Suite NinjaScript generated accessor/cache region remains stale pending NinjaTrader regeneration.
- After targeted deployment, NinjaTrader regenerated the live accessor/cache signature to include `StepBasis` and `SessionConfiguration`; this is not being counted as an F5 compile result.

## Deployment status

- Targeted deployment completed with `deploy_orca.ps1 -Target OrcaStepProfile`.
- Live destination: `C:\Users\julia\Documents\NinjaTrader 8\bin\Custom\Indicators\OrcaStepProfile.cs`.
- Authored-region parity between Working_Suite and the live copy passed.
- The live copy contains one generated-code region, one Session basis member, and one Session Configuration property.

## Manual-validation status

- Pending Julian's live NinjaTrader chart validation.
- Validate both configurations across 6:00 PM, 3:00 AM, 9:30 AM, and the configured RTH close.
- Confirm the selected Trading Hours template includes the overnight periods.

## Known issues, risks, and follow-up work

- Session timestamps assume the chart data is Eastern-aligned, matching the existing Orca time-setting convention.
- Session mode deliberately hardcodes 6:00 PM, 3:00 AM, and 9:30 AM; only the close remains configurable through `RTH End Time`.
- On a Trading Hours template with no post-close ticks, the just-completed RTH/New York block cannot be moved to the historical rendering path until the next available tick arrives.
- Existing unrelated uncommitted work in `OrcaStepProfile.cs` remains present and was not reverted.

## Promotion eligibility

- Not eligible for promotion to `Full_Suite` until NinjaTrader F5 compilation succeeds and Julian confirms live behavior for both session configurations.
