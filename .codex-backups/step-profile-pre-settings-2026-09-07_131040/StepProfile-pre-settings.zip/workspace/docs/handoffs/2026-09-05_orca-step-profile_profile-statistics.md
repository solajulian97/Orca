# Orca Step Profile Per-Profile Statistics

## Objective

Add an opt-in compact statistics row to each active and completed Orca Step Profile while preserving existing profile construction, aggregation, placement, and default chart appearance.

## Files Changed

- `Orca Trades/Working_Suite/Indicators/OrcaStepProfile.cs`
- `docs/handoffs/2026-09-05_orca-step-profile_profile-statistics.md`

`Orca Trades/Full_Suite` was not modified. The indicator source already contained substantial unrelated uncommitted work; this change was limited to StepBlock statistics state, its existing trade-allocation hook, statistics rendering/resources, and new properties.

## Behavior Added Or Changed

- Each `StepBlock` now maintains `CumulativeDelta`, `MaxCumulativeDelta`, and `MinCumulativeDelta` in trade-event order.
- The scalars update under the existing block lock in `AddTickToBlock`, using the same `signedVolume` allocation that updates `DeltaByPrice`.
- Time, Session, ordinary Volume, and split Volume blocks therefore share one accumulation path. A split trade contributes only the allocated volume and signed volume passed to each block.
- Completed blocks retain their final scalar values; a new block begins with zero volume, delta, and extrema.
- One compact row can be drawn for each visible completed block and for the active block: `T +570 | F -120 | +8.4% | V 254.1K`.
- Disabled metrics are omitted without leading, trailing, or doubled separators.

## Statistic Definitions

- **Total Delta (`T`)**: cumulative buyer-initiated volume minus seller-initiated volume for that individual block. Unclassified volume contributes zero Delta.
- **Finish Delta (`F`)**: `currentDelta - (currentDelta >= 0 ? maxCumulativeDelta : minCumulativeDelta)`, matching Orca Leg-to-Leg Profile, including its zero-final-delta sign rule.
- **Delta Percent (`%`)**: `TotalDelta / TotalVolume * 100`, or zero when total volume is zero. Total volume includes unclassified volume.
- **Total Volume (`V`)**: the existing `StepBlock.TotalVolume`; no duplicate counter or render-time map sum was added. Values below 1,000 remain unscaled, values from 1,000 use one-decimal `K`, and values from 1,000,000 use one-decimal `M`, with invariant formatting.

## User-Facing Settings

Added under `Profile Statistics`:

- `Show Profile Statistics`: default `False`.
- `Show Active Statistics`: default `True`.
- `Show Historical Statistics`: default `True`.
- `Show Total Delta`: default `True`.
- `Show Finish Delta`: default `True`.
- `Show Delta Percent`: default `True`.
- `Show Total Volume`: default `True`.
- `Statistics Font Size`: default `12`, range `8` to `30`.
- `Statistics Text Color`: default `White`, with standard NinjaTrader brush serialization.

All properties remain visible when the master switch is off. Because the master switch defaults off, existing charts retain their prior appearance.

## Secondary Series Added Or Changed

None. The existing optional Tick 1 secondary series and Tick Replay Last-event path are unchanged. No Tick, Second, Bid, Ask, Volumetric, or custom series was added or changed.

## Tick Replay Implications

Tick Replay classification is unchanged. Its existing classified events now update the same per-block scalars as live and secondary-series events. Statistics visibility does not control accumulation.

## Historical-Load Implications

Historical reconstruction continues through the existing event-classification and `AddTickToBlock` path. No historical scan, tick-history collection, or rebuild was added. Historical profiles need to be reconstructed after the new source is compiled for their scalar statistics to exist.

## Cache Implications

None. No shared cache, local cache, database, or persistence format changed. The new NinjaScript properties will enter generated accessor/cache identity after NinjaTrader regenerates its generated region during compilation.

## Rendering And SharpDX Implications

- Statistics draw once per block from `RenderStepProfiles`, not from both Volume and Delta row renderers.
- Completed rows use the block's logical `startX`/`endX`, right-align four pixels inside `endX`, and remain inside the existing period clip. Narrow periods clip rather than bleed into the next block.
- The active row derives its lane from the actual visible Volume/Delta geometry for both mirror arrangements and both unmirrored Overlay/Side-by-Side modes. If only one active component is visible, its actual lane edge is used.
- Active and historical text rectangles are clamped four pixels inside the chart panel, with trailing alignment and whole-pixel rectangle coordinates.
- A dedicated render-target-bound statistics brush and DirectWrite `TextFormat` are reused, disposed on target change/termination, and rebuilt when the statistics font size changes.
- No per-block `TextLayout`, `TextFormat`, or brush allocation was added.

## Performance Implications

The event path adds three scalar arithmetic/extrema updates under an existing lock. Rendering snapshots four scalar values under that lock, builds one short string per enabled visible block, and performs one text draw. It does not sum maps, rebuild profiles, access caches, add synchronization waits, or allocate DirectWrite resources per block.

## Automated Checks

- C# 7.3 Roslyn authored-source syntax parse: passed with zero errors.
- Offline authored-region semantic compilation against installed NinjaTrader, WPF, SharpDX, `NinjaTrader.Custom.dll`, and the current diagnostics contract: passed with zero errors.
- Executed the actual extracted production Finish Delta and formatting methods in a disposable Roslyn fixture.
- Assertions passed for all-buy, all-sell, positive and negative retracement, flat-zero sign behavior, unclassified-volume percentage dilution, signed formatting, zero, percentage precision, `K`/`M` thresholds, and all 16 metric-visibility combinations.
- Split-allocation model reconciliation passed, and source-contract assertions confirmed both maps and scalar statistics use `signedVolume` while `TotalVolume` uses the allocated `volume`.
- Structural checks passed: balanced braces, one generated-code region, and one declaration for each new setting.
- `git diff --check` passed for the indicator source; Git reported only its existing LF-to-CRLF conversion warning.
- Targeted deployment with `deploy_orca.ps1 -Target OrcaStepProfile` succeeded.
- Normalized authored source/live parity passed with SHA-256 `00725d84e2fddb9dc8a3be0217979ada05c544f0bdddcdb8330cc4343b6ffd67`.
- Live generated-code inspection confirmed the new statistics properties are present in the regenerated indicator, Market Analyzer, and Strategy accessors/cache identity.
- NinjaTrader's source watcher rebuilt `NinjaTrader.Custom.xml`, PDB, and DLL after the final deployment; the DLL timestamp is `2026-09-05 21:47:09 UTC`.

## NinjaTrader Compile Status

Automatic source-watcher semantic compilation passed: NinjaTrader regenerated the accessors and rebuilt `NinjaTrader.Custom.dll` after deployment. An explicit NinjaScript Editor F5 invocation was not performed and is not claimed; indicator load and chart behavior remain separate validation gates.

## Manual-Validation Status

Pending Julian's NinjaTrader validation:

1. Press F5 and confirm no compiler errors and that all nine properties appear under `Profile Statistics` with the documented defaults.
2. Enable the master switch and inspect Time, Volume, and Session bases with active and completed profiles.
3. Check Volume-only, Delta-only, and combined visibility in both active mirror arrangements and unmirrored Overlay/Side-by-Side modes.
4. Confirm the active row stays visible beside the price scale and completed rows clip inside narrow periods.
5. Pan, zoom, switch dynamic/fixed widths, reload, remove/re-add, and recreate the SharpDX target.
6. Compare Playback, Tick Replay, and live values, including volume-step split boundaries and unclassified volume.

## Known Risks And Follow-Up Work

- Very narrow completed periods intentionally clip the compact row; they do not expand or overlap a neighboring period.
- A 999,999 total formats as `1000.0K`, while 1,000,000 formats as `1.0M`, because suffix selection occurs at the exact raw `K`/`M` thresholds.
- Offline semantic compilation and the automatic source-watcher build are not an explicit NinjaTrader F5, indicator-load, Playback, Tick Replay, or live-data test.
- The source remains part of a mixed dirty worktree, so no commit was created to avoid bundling unrelated edits.

## Promotion Eligibility

Not eligible for promotion to `Orca Trades/Full_Suite` until NinjaTrader F5 succeeds and Julian confirms the settings, values, clipping, active layouts, reload, Playback, Tick Replay, and live chart behavior.
