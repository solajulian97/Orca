# Orca Step Profile Non-RTH Volume-Chart Width Override

## Objective

Make completed non-RTH session profiles easier to read on native Volume charts without widening RTH profiles or changing active-profile behavior.

## Files changed

- `Orca Trades/Working_Suite/Indicators/OrcaStepProfile.cs`
- `docs/handoffs/2026-08-26_orca-step-profile_non-rth-volume-width.md`

## Behavior added, changed, or removed

- Added an opt-in width override for completed non-RTH session profiles on native NinjaTrader Volume charts.
- In `Overnight / RTH` mode, the override applies to completed Overnight blocks.
- In `Asian / London / New York` mode, the same override applies to completed Asia and London blocks.
- RTH profiles continue using the global `Fill Space Percent`.
- Disabling the override preserves the existing width behavior.
- Non-Volume charts ignore the override.
- Fixed historical width mode, the active right-edge profile, and all delta widths remain unchanged.

## User-facing settings added, changed, deprecated, or removed

The `Layout` section adds directly after `Fill Space Percent`:

- `Override Non-RTH Width on Volume Charts` (default off)
- `Non-RTH Fill Space Percent` (default 100, range 10-100)

The remaining Layout display orders were normalized so each existing setting keeps a deterministic position. No existing setting was renamed or removed.

## Secondary series added or changed

No secondary series were added or changed. Existing trade-source behavior remains unchanged.

## Tick Replay implications

No Tick Replay requirement or behavior changed.

## Historical-load implications

No historical aggregation, session construction, period boundary, or load behavior changed.

## Cache implications

No local or shared profile-data cache behavior changed.

## Rendering implications

- The historical volume-width resolver now receives the completed `StepBlock` so it can identify non-RTH session starts.
- The override requires dynamic profile width, Session basis, a native `BarsPeriodType.Volume` primary series, and a session start before the fixed 9:30 AM RTH boundary.
- Eligible blocks use `periodWidth * NonRthFillSpacePercent / 100`; all other blocks use the existing global percentage.
- Existing logical period bounds and SharpDX clipping remain authoritative, including at 100 percent.
- Active-profile and historical-delta render paths are unchanged.

## Performance implications

Eligible historical blocks add only constant-time setting, bar-type, and timestamp checks during rendering. No allocations, profile rebuilding, collection mutation, cache access, or synchronization were added to `OnRender`.

## Tests performed in NinjaTrader

Pending F5 compilation and live chart testing.

## Static tests performed

- Roslyn syntax parsing passed with zero errors.
- Opening and closing brace counts match.
- `git diff --check` passed with only the repository line-ending warning.
- Layout orders are unique and sequential from 8 through 24.
- Source audit confirmed the opt-in false default, 100 percent preset, block-aware historical call, Session-basis guard, native Volume-bar guard, fixed 9:30 AM RTH boundary, unchanged active fixed-width call, unchanged historical-delta helper call, and one generated-code region.
- Boundary matrix confirmed Overnight/Asia and London qualify while RTH does not; override-off, non-Volume, and non-Session cases are guarded out.
- Live authored-region parity passed with SHA-256 `72DEA4E0804AE9357D786253D48F5349F40C7E5D3F68DF4144E15E0A1B046345`.
- The live file contains one declaration for each new setting and one generated-code region.

## Compile status

Targeted deployment completed with `deploy_orca.ps1 -Target OrcaStepProfile`. NinjaTrader F5 compilation remains pending.

## Manual-validation status

Pending. Validate both session configurations on a native Volume chart with the override off and on, then verify RTH, active, delta, non-Volume, fixed-width, zoom, scroll, and mirror behavior.

## Known issues, risks, and follow-up work

- The settings remain visible on non-Volume charts but intentionally have no effect there.
- Session classification preserves the existing Eastern-aligned 6:00 PM, 3:00 AM, and 9:30 AM boundaries.
- Existing unrelated uncommitted Step Profile work was preserved.

## Promotion eligibility

Not eligible for promotion to `Full_Suite` until NinjaTrader compiles and Julian confirms live behavior.
