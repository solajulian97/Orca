# Orca Step Profile Four-Hour Session Anchor

## Objective

Align four-hour step profiles to the 6:00 PM trading-day boundary used by the indicator's daily profile.

## Files Changed

- Orca Trades/Working_Suite/Indicators/OrcaStepProfile.cs
- docs/handoffs/2026-08-01_orca-step-profile_four-hour-session-anchor.md

## Behavior Added, Changed, Or Removed

- Four-hour blocks now begin at 6:00 PM, 10:00 PM, 2:00 AM, 6:00 AM, 10:00 AM, and 2:00 PM.
- Daily, hourly, 30-minute, and 15-minute alignment behavior is unchanged.

## User-Facing Settings

- No settings were added, changed, deprecated, or removed.

## Secondary Series

- No secondary series were added or changed. The existing hidden 1-tick series remains unchanged.

## Tick Replay Implications

- No Tick Replay behavior was changed.

## Historical-Load Implications

- Historical four-hour blocks are rebuilt using the new 6:00 PM alignment when the indicator recalculates.

## Cache Implications

- No cache behavior was changed.

## Rendering Implications

- Rendering code was not changed. Existing historical and active profile rendering behavior is preserved.

## Performance Implications

- Negligible. Four-hour alignment performs one date subtraction and integer bucket calculation when a block is created.

## Tests Performed In NinjaTrader

- Not yet performed.

## Deployment Status

- Targeted deployment to Documents/NinjaTrader 8/bin/Custom/Indicators/OrcaStepProfile.cs completed.
- Working_Suite and live-file SHA-256 hashes matched after deployment.

## Compile Status

- NinjaTrader F5 compile pending.

## Manual-Validation Status

- Pending verification that four-hour blocks appear at 6 PM, 10 PM, 2 AM, 6 AM, 10 AM, and 2 PM across a trading day.

## Known Issues, Risks, And Follow-Up Work

- The 6:00 PM anchor intentionally follows the indicator's existing daily-profile convention rather than querying the chart trading-hours template.
- Charts whose intended trading day begins at a different time will still use 6:00 PM for the four-hour option.
- The separate Draw Behind Candles limitation remains unresolved.

## Promotion Eligibility

- Not eligible for promotion to Full_Suite until NinjaTrader compiles and Julian confirms live chart behavior.
