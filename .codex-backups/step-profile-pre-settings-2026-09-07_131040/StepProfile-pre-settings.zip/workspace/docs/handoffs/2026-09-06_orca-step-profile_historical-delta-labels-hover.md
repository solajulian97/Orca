# Step Profile Historical Delta Labels And Hover

## Objective and scope

Give historical delta labels independent value/zoom filtering and hover-only inspection. Active delta labels and profile/statistics calculations retain existing behavior. Full_Suite is untouched.

Files changed:
- `Orca Trades/Working_Suite/Indicators/OrcaStepProfile.cs`
- `tests/OrcaStepProfile.PlatformCheck/OrcaStepProfile.PlatformCheck.csproj`
- `tests/OrcaStepProfile.PlatformCheck/Program.cs`
- This handoff.

## Settings and behavior

New `Historical Delta Text` group, with all controls always visible:
- `Historical Label Mode`: defaults to `FollowGlobal`, preserving the existing Show Delta Text, Minimum Threshold, and hard-coded six-pixel row-height gate. `Filtered` uses the three historical thresholds independently of Show Delta Text. `HoverOnly` suppresses ordinary historical labels and automatically enables hover. `Hidden` suppresses both labels and hover.
- `Minimum Absolute Delta`: default 500, range 0 through int.MaxValue; applies to the displayed aggregated row in Filtered mode. Zero allows every value.
- `Minimum Row Height (px)`: default 6, range 0-100; applies in Filtered mode. This responds to vertical scaling but dynamic aggregation may maintain row height while zoomed out.
- `Minimum Bar Spacing (px)`: default 0, range 0-100; horizontal zoom gate in Filtered mode. Zero disables this cutoff. Uses average visible chart-bar center spacing, independent of dynamic price aggregation.
- `Reveal Delta on Hover`: default false; permits hover in FollowGlobal/Filtered independently of thresholds. HoverOnly enables it automatically; Hidden always suppresses it.

Suggested configuration: Filtered, minimum delta 500, row height 12, bar spacing 8, hover reveal enabled. For all values, Filtered with zero minimum delta and optional zero zoom cutoffs. For hover alone, select HoverOnly.

## Rendering and lifecycle

Mouse coordinates use chart-relative WPF coordinates converted to device pixels, following the Candle Volume Profile coordinate pattern. Hit testing is performed during the existing delta draw loop against the current aggregated row rectangle intersected with its actual historical clip and chart panel. No expanded hit area includes off-screen or clipped-away parts. The last matching drawn historical row wins when profiles overlap.

One tooltip uses the matching row's signed delta and existing positive/negative text colors. It is drawn after profiles and clamped inside the chart panel. The tooltip uses a persistent 12px no-wrap DirectWrite format and dark background brush, disposed with existing resources and recreated with the render target. No tick/map lookup, new per-row resource, or retained row hit list is required. The hit resets each render and clears on mouse leave; drag-button states suppress hover. Mouse move redraw requests are capped at approximately 30 per second while hover is enabled. Hover reuses the indicator's existing render path, so its existing aggregation cost is still incurred on those redraws; performance requires live inspection.

Mouse handlers attach through the chart dispatcher in Historical/Realtime and detach at termination. They do not capture the mouse or mark events handled. The existing visibility hotkey suppresses hover rendering and redraw requests.

## Data and performance implications

Secondary-series changes: none. Existing optional Tick 1 AddDataSeries, OnMarketData classification, Calculate mode, Tick Replay, Playback ingestion, and historical reconstruction are unchanged. No shared provider/cache access or new subscriptions to market data were added. No full historical rebuild or model mutation was introduced. Existing profile computations in rendering were not refactored. Added work is constant-time filtering/hit testing per rendered historical delta row and one tooltip draw when hit.

## Verification and deployment

- `dotnet run --project tests/OrcaStepProfile.PlatformCheck --configuration Release`: zero offline C# 7.3/NinjaTrader semantic errors.
- Eleven cases execute the actual authored label-decision statements extracted with Roslyn: global inheritance, exact threshold equality, both delta signs, value/vertical/horizontal rejection, HoverOnly/Hidden, and active-profile bypass.
- `git diff --check` passed for Step Profile (existing line-ending warning only).
- Targeted `deploy_orca.ps1 -Target OrcaStepProfile` succeeded.
- Normalized authored source/live parity passed, SHA256 `BBBF43510C4EAF438713765E9B8456453C15482F92382E776DF1E1CB9D856456`.
- NinjaTrader regenerated the hover properties in its accessor/cache region and regenerated Custom DLL at 2026-09-06 18:24:46 local time, after source deployment at 18:24:39. This is automatic-build evidence only.

## Pending validation and risks

Explicit NinjaScript Editor F5, assembly load, chart interaction, and manual validation are pending. No NinjaTrader UI tests were performed. Julian should check both mirror arrangements, partial periods, dynamic/fixed aggregation, active labels, narrow rows, high-DPI monitors, horizontal/vertical zoom, chart pan, mouse leave, visibility toggle, removal/re-add, and render-target recreation. Check Playback and Tick Replay separately. A very small delta bar is deliberately a small hover target; hover does not widen the profile or reveal a zero-width row.

The existing source contains substantial unrelated uncommitted changes. No whole-file commit was made because it would include those changes. Full_Suite promotion is not eligible until Julian confirms F5 and manual chart behavior.
