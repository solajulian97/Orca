# Orca Step Profile Dynamic Volume Data Menu

## Objective

Make the Orca Step Profile Data settings consistent with Orca Candle Volume Profile by adding independent dynamic volume aggregation controls and placing the RTH controls together after the volume and order-flow controls.

## Files Changed

- `Orca Trades/Working_Suite/Indicators/OrcaStepProfile.cs`
- `docs/handoffs/2026-08-01_orca-step-profile_dynamic-volume-data-menu.md`

## Behavior Added, Changed, Or Removed

- Added optional dynamic aggregation for the volume profile rows.
- The configured Volume Row Size remains the minimum row size.
- The Volume Dynamic Multiplier changes how quickly row size increases as the visible price range grows relative to chart height.
- Max Dynamic Volume Ticks caps the dynamically selected row size.
- Dynamic volume aggregation is disabled by default, preserving the prior fixed-row behavior for existing instances.
- Existing order-flow/Delta aggregation behavior and calculations were preserved.
- RTH filtering behavior was not changed; only its property ordering was corrected.

## User-Facing Settings

- Renamed `Volume Tick Compression` display text to `Volume Row Size (ticks)`.
- Added `Dynamic Volume Aggregation`.
- Added `Volume Dynamic Multiplier`.
- Added `Max Dynamic Volume Ticks`.
- Renamed existing Delta display labels to the Candle Volume Profile's `Order Flow` terminology without changing their backing properties or behavior.
- Ordered `RTH Only`, `RTH Start Time`, and `RTH End Time` together at the end of the Data section.

## Secondary Series

No secondary series were added, removed, or changed. The existing hidden 1-tick Last series remains unchanged.

## Tick Replay Implications

No Tick Replay behavior changed. Dynamic volume aggregation only regroups already collected volume buckets for rendering.

## Historical-Load Implications

No historical profile rebuild path changed. Historical profiles retain the same collected volume. Their rendered POC and value-area cache is recalculated only when the resolved dynamic volume compression changes.

## Cache Implications

- Added the volume compression value to each historical block's POC/value-area cache key.
- No shared profile cache behavior was added or changed.

## Rendering Implications

- Volume rows are regrouped at render time only when the resolved dynamic row size exceeds the configured base row size.
- POC and value area are calculated from the same regrouped volume map that is rendered.
- Profile anchoring, active-profile placement, clipping, colors, opacity, labels, and Delta rendering were not changed.

## Performance Implications

- Fixed volume aggregation uses the existing dictionary directly and adds no regrouping allocation.
- Dynamic aggregation creates one grouped dictionary per rendered profile when its resolved row size exceeds the base row size.
- No full historical rebuild, data access, secondary-series work, or synchronization wait was added to `OnRender`.

## Tests Performed In NinjaTrader

Not yet performed. Julian must compile with F5 and inspect the settings and chart behavior.

## Compile Status

NinjaTrader F5 compile pending. Static source checks passed: balanced braces, unique new property definitions, and `git diff --check`.

## Deployment Status

Deployed to `C:\Users\julia\Documents\NinjaTrader 8\bin\Custom\Indicators\OrcaStepProfile.cs` with the targeted Orca deploy script. The authored source regions match exactly. The full-file hashes differ because deployment preserves NinjaTrader's generated factory/cache region; exactly one generated region is present and F5 regeneration is pending.

## Manual-Validation Status

Pending. Validate fixed mode parity, dynamic volume response while zooming, max-tick capping, POC/value-area updates, and the reordered Data menu.

## Known Issues, Risks, And Follow-Up Work

- The NinjaScript-generated factory/cache region remains generated content and is expected to refresh during NinjaTrader F5 compilation.
- Dynamic regrouping follows the same gentle tick sequence and visible-price-range formula as Orca Candle Volume Profile.
- The user's final sentence in the request was incomplete; no additional unspecified setting was changed.

## Full_Suite Promotion Eligibility

Not eligible until NinjaTrader F5 compilation and Julian's live manual validation are complete.
