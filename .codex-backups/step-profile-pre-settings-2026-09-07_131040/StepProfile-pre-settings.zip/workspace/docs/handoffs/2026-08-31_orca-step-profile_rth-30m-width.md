# Orca Step Profile RTH Time-Chart Width Override

## Objective

Make completed RTH session profiles fill their complete logical session span on Minute-based time charts while retaining the user-selected dynamic percentage for Overnight profiles.

## Files changed

- `Orca Trades/Working_Suite/Indicators/OrcaStepProfile.cs`
- `docs/handoffs/2026-08-31_orca-step-profile_rth-30m-width.md`

## Behavior added, changed, or removed

- Added an RTH width override for completed Session-basis profiles on Minute-based time charts.
- The RTH override is enabled by default at 100 percent so the RTH profile reaches the end of its own logical session span.
- Overnight remains controlled by the existing global `Fill Space Percent`, such as 50 percent.
- The existing native Volume-chart non-RTH override remains independent and continues to apply only to Overnight, Asia, and London profiles when enabled.
- The override does not apply to non-Session bases, non-time charts, or active profiles.

## User-facing settings added, changed, deprecated, or removed

The `Layout` section adds directly after the existing non-RTH controls:

- `Override RTH Width on Time Charts` (default on)
- `RTH Fill Space Percent (Time)` (default 100, range 10-100)

The remaining Layout display orders were shifted to remain unique and deterministic. No existing setting was renamed or removed.

## Secondary series added or changed

No secondary series were added or changed. Existing trade-source behavior remains unchanged.

## Tick Replay implications

No Tick Replay requirement or behavior changed.

## Historical-load implications

No historical aggregation, session construction, period boundary, or load behavior changed.

## Cache implications

No local or shared profile-data cache behavior changed.

## Rendering implications

- The completed historical volume-width resolver now selects an RTH-specific percentage before the existing non-RTH Volume-chart override and global percentage.
- The RTH override requires `Dynamic Profile Width`, `Step Basis = Session`, `BarsPeriodType.Minute` at any Minute value, and an RTH block beginning at the existing 9:30 AM Eastern-aligned boundary.
- RTH width is calculated from the RTH block's own logical `startX` and `endX`, capped by the existing period width and rendered through the existing SharpDX clipping.
- Overnight uses the normal global fill percentage on all qualifying time charts.
- Active-profile geometry, historical-delta geometry, session construction, and profile calculations are unchanged.

## Performance implications

The change adds only constant-time setting, bar-type/value, and session-boundary checks for each completed historical block. No allocations, profile rebuilding, collection mutation, cache access, or synchronization were added to `OnRender`.

## Tests performed in NinjaTrader

Pending F5 compilation and live chart testing.

## Static tests performed

- Roslyn syntax parsing passed with zero errors.
- Opening and closing brace counts match.
- `git diff --check` passed with only the repository line-ending warning.
- Layout orders are unique and sequential from 8 through 26.
- Source audit confirmed the enabled 100 percent defaults, block-aware historical call, Session-basis guard, Minute-bar guard for any Minute value, fixed 9:30 AM RTH boundary, unchanged active fixed-width call, unchanged historical-delta helper call, and one generated-code region.
- Boundary matrix confirmed RTH qualifies on Minute-based Session charts while Overnight/Asia and London do not use the RTH override; non-time, non-Session, and override-off cases are guarded out.
- The old 30-minute-only identifiers and `BarsPeriod.Value` restriction are absent.
- Live authored-region parity passed with SHA-256 `55BFD0C7B0CC878BD0B5FC95CB60BD85935B6B98DE5E079076ED4D04998AB520`.
- The live file contains one declaration for each new setting and one generated-code region.

## Compile status

Targeted deployment completed with `deploy_orca.ps1 -Target OrcaStepProfile`. NinjaTrader F5 compilation remains pending.

## Manual-validation status

Pending. Validate Minute-based Session charts with global Fill Space Percent at 50 percent: RTH should use 100 percent and Overnight should use 50 percent. Test several Minute values, then validate the toggle off, non-time charts, non-Session bases, both session configurations, zoom/scroll, mirror arrangements, active profile, and delta widths.

## Known issues, risks, and follow-up work

- The controls remain visible on other chart types but intentionally have no effect there.
- The RTH boundary follows the existing fixed 9:30 AM Eastern-aligned Session-mode logic.
- Existing unrelated uncommitted Step Profile work was preserved.

## Promotion eligibility

Not eligible for promotion to `Full_Suite` until NinjaTrader compiles and Julian confirms live behavior.
