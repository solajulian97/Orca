# Orca Step Profile Close-Stamped Boundary Index

## Objective

Align Step Profile separators and profile spines with the first primary chart bar after each logical block boundary. On an hourly chart, the 6:00 PM trading-day boundary must render at the 7:00 PM close-stamped bar rather than the preceding 5:00 PM bar.

## Files changed

- `Orca Trades/Working_Suite/Indicators/OrcaStepProfile.cs`
- `docs/handoffs/2026-08-17_orca-step-profile_historical-mirror-session-anchor.md`
- `docs/handoffs/2026-08-17_orca-step-profile_close-stamped-boundary-index.md`

## Behavior added, changed, or removed

- Boundary-to-bar resolution now finds the first primary bar whose timestamp is strictly later than the logical boundary.
- A daily block beginning at 6:00 PM maps to the 7:00 PM bar on a 60-minute close-stamped chart.
- Session boundaries use the same rule: for example, a 3:00 AM boundary maps to 3:01 AM on a one-minute chart or 3:30 AM on a thirty-minute chart.
- Initial Time-basis blocks now use the same deterministic resolver as subsequent blocks instead of inheriting the current primary bar index.
- Separator and historical profile spine continue to share the block's `StartBarIndex`.

## User-facing settings added, changed, deprecated, or removed

- No settings were added, changed, deprecated, or removed.

## Secondary series added or changed

- No secondary series were added or changed.
- The existing selected trade-source path remains unchanged.

## Tick Replay implications

- No Tick Replay behavior changed.
- The correction only maps logical timestamps onto the primary chart's bar indices.

## Historical-load implications

- Historical boundary lookup uses a binary search over the already-loaded primary bar timestamps.
- No historical profile rebuild or additional historical-data request was added.

## Cache implications

- No cache behavior changed.

## Rendering implications

- Rendering code is unchanged.
- Corrected `StartBarIndex` values move both the separator and profile spine to the proper close-stamped chart bar.

## Performance implications

- Boundary lookup is `O(log n)` and runs only when a block is created or finalized, not for every rendered row or every ordinary tick.
- No allocations, render passes, locks, or data subscriptions were added.

## Tests performed in NinjaTrader

- Pending Julian's F5 compile and chart validation.

## Static tests performed

- `git diff --check` passed for the scoped files; only the existing line-ending conversion warning was reported.
- Boundary simulations passed:
  - `[5:00 PM, 7:00 PM, 8:00 PM]` with a 6:00 PM boundary resolves to 7:00 PM.
  - `[2:59 AM, 3:00 AM, 3:01 AM]` with a 3:00 AM boundary resolves to 3:01 AM.
  - `[2:30 AM, 3:00 AM, 3:30 AM]` with a 3:00 AM boundary resolves to 3:30 AM.
- The deployed NinjaTrader copy contains the corrected initial-block and binary-search paths.
- Normalized authored-region parity between `Working_Suite` and the live NinjaTrader copy passed.

## Compile status

- NinjaTrader F5 compile pending after deployment.

## Deployment status

- Targeted deployment completed with `deploy_orca.ps1 -Target OrcaStepProfile`.
- Live destination: `C:\Users\julia\Documents\NinjaTrader 8\bin\Custom\Indicators\OrcaStepProfile.cs`.

## Manual-validation status

- Pending validation on the daily Step Profile using a 60-minute chart.
- Confirm the 6:00 PM boundary appears on the bar labeled 7:00 PM and no separator remains on the preceding 5:00 PM bar.
- Session-mode checks at 3:00 AM and 9:30 AM remain recommended on one-minute and thirty-minute charts.

## Known issues, risks, and follow-up work

- This follows NinjaTrader's close-stamped time-bar convention. Non-time primary BarsTypes should be checked separately if their timestamp convention differs.
- A boundary later than every currently available primary bar resolves to the next bar index and becomes visible when that bar exists.

## Promotion eligibility

- Not eligible for promotion to `Full_Suite` until NinjaTrader compiles and Julian confirms the corrected live chart alignment.
