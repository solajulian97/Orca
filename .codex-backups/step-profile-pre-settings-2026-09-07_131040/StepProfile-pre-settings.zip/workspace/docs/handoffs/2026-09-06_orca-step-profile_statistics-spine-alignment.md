# Step Profile Statistics Spine Alignment

## Objective

Align completed-profile statistics to their shared volume/delta spine and prevent active statistics from overlapping the historical row.

## Files changed

- `Orca Trades/Working_Suite/Indicators/OrcaStepProfile.cs`
- This handoff.

## Behavior and rendering

Historical statistics previously ended at the period end, and both active and historical statistics occupied the same top row. Historical statistics now end four pixels before their own start/spine X. Their separate text rectangle extends left to the preceding block's spine, clipped to the panel. This intentionally moves statistics outside the profile histogram's period clip; histogram clipping is unchanged. Offscreen spines do not get reanchored to the panel edge. Narrow spaces clip the single-line text without wrapping or bleeding into adjacent statistics lanes.

Active statistics retain their existing horizontal anchor but use the next line (row height plus two pixels lower) whenever historical statistics are enabled. This deterministically separates the two datasets even while scrolling. No settings or defaults changed.

## Data and performance

Secondary series changes: none. AddDataSeries, OnMarketData, Calculate mode, Tick Replay, Playback, historical ingestion, trade classification, caches, scalar statistics, and volume/delta calculations are unchanged. No new market data or shared-cache access. Rendering adds one preceding-spine X lookup per visible historical statistics row; no new resources or text measurements. Existing persistent statistics format is now explicitly no-wrap; DrawText explicitly clips to its rectangle.

## Verification

Offline C# 7.3 NinjaTrader semantic compilation: zero errors. Existing eleven label filter cases pass. F5 and manual chart validation remain pending. Inspect historical spine alignment, narrow periods, pan/zoom, active second-row placement, both mirror arrangements, and multiple indicator instances separately. Independent indicator instances still own independent statistics placement; this change does not coordinate rows across indicators.

Targeted deployment succeeded and normalized authored source/live parity passed. NinjaTrader Custom DLL regenerated at 2026-09-06 18:53:16 local time, after deployment at 18:53:12. Automatic assembly generation is not explicit F5 or chart-load validation. Scoped git diff --check passed.

## Promotion and commit status

Full_Suite untouched; not eligible until Julian confirms NinjaTrader F5 and chart behavior. The target file includes pre-existing uncommitted work; no whole-file commit was made that would bundle those changes.
