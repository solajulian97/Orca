# Orca Step Profile Mirror, Active Layout, and Trade Source

## Objective

Fix historical mirrored Step Profiles so Volume and Delta both remain visible, add an active side-by-side layout with both profiles facing left, and add an explicit Tick Replay trade source that uses Bid/Ask values attached to historical Last events.

## Files changed

- `Orca Trades/Working_Suite/Indicators/OrcaStepProfile.cs`
- `docs/handoffs/2026-08-17_orca-step-profile_mirror-layout-trade-source.md`

## Behavior added, changed, or removed

- Historical mirrored profiles now place their shared spine inside the profile period rather than at its left clipping boundary.
- Historical Volume and Delta widths share the available period width. When their requested combined width is too large, both are scaled proportionally so neither side is clipped away.
- Both historical mirror arrangements are retained:
  - Delta left / Volume right
  - Volume left / Delta right
- Added an active unmirrored side-by-side layout:
  - Volume remains nearest the active right-edge spine and faces left.
  - Delta is positioned immediately to the left of Volume and also faces left.
- Legacy active overlay behavior remains the default.
- Added exclusive trade-source routing:
  - Secondary Tick Series processes only hidden-series `OnBarUpdate` ticks.
  - Tick Replay Last Events does not add the hidden tick series and processes only `MarketDataType.Last` events.
- Tick Replay Last Events uses the Bid and Ask attached to each Last event before falling back to the existing price-change direction rule for trades not classified at Bid or Ask.
- Selecting Tick Replay Last Events without enabling chart Tick Replay prints a warning. Historical profiles remain unavailable until Last events are available; the indicator does not silently mix or double-count sources.

## User-facing settings

- Added `Trade Source Mode` under Data:
  - `Secondary Tick Series` (default)
  - `Tick Replay Last Events`
- Added `Active Unmirrored Layout` under Layout:
  - `Overlay` (default)
  - `Side by Side (Both Left)`
- Existing `Mirror Profiles` and `Mirror Arrangement` settings remain compatible.

## Secondary series

- `Secondary Tick Series` mode retains the existing hidden 1-tick Last series.
- `Tick Replay Last Events` mode adds no secondary series.
- No Bid, Ask, Second, Volumetric, or custom series were added.
- The two modes are mutually exclusive at `State.Configure`, preventing duplicate trade processing.

## Tick Replay implications

- Tick Replay Last Events requires Tick Replay enabled on the chart's primary Data Series.
- In this mode, historical and live trades are processed from `OnMarketData(MarketDataType.Last)` using `e.Price`, `e.Volume`, `e.Bid`, and `e.Ask`.
- Secondary Tick Series remains the faster legacy mode and estimates historical Delta from cached live quotes when available, otherwise from price changes between ticks.
- The indicator does not automatically fall back from Tick Replay mode to the secondary series because doing so would require both sources and risk duplicated or discontinuous profile data.

## Historical-load implications

- Secondary mode continues loading historical 1-tick Last data through the hidden series.
- Tick Replay mode rebuilds profiles from historical Last market-data events and their trade-time inside Bid/Ask values.
- Historical availability and fidelity still depend on the connected provider's historical tick data.
- Switching Trade Source Mode changes the configured data path and requires NinjaTrader to reload the indicator.

## Cache implications

- No shared or persistent cache was added or changed.
- Both trade sources publish into the existing `StepBlock` volume and Delta maps.

## Rendering implications

- Historical mirrored geometry now uses one combined width budget inside the existing per-period SharpDX clip.
- Value-area line bounds use the resolved Delta width so lines follow the scaled mirrored pair.
- Active side-by-side mode shifts only the Delta root and value-area span; it does not add a second render pass.
- No model calculation or cache work was added to `OnRender`.

## Performance implications

- Secondary mode has the same hidden-series cost as before.
- Tick Replay mode removes the hidden secondary series but enabling NinjaTrader Tick Replay has a platform-level historical processing and memory cost.
- Each trade is processed by exactly one source.
- Historical width resolution is constant-time per rendered block and adds no profile-map copies or per-row allocations.

## Tests performed

- `git diff --check` passed for `OrcaStepProfile.cs` (line-ending warning only).
- Static routing audit confirmed:
  - one conditional `AddDataSeries` declaration
  - one secondary-series processing path
  - one Tick Replay Last-event processing path
  - zero remaining implicit `ClassifyTickDirection(last)` calls
  - zero remaining parameterless `ProcessTickIntoActiveBlock()` calls
- Structural checks confirmed balanced braces and parentheses and one NinjaScript generated-code region.
- Historical geometry simulations passed for both arrangements at 100 px, 300 px, and compressed 20 px periods; Volume and Delta bounds remained inside each period.
- Active side-by-side simulation placed a 150 px Volume profile at `[350,500]` and a 60 px Delta profile at `[290,350]`, confirming Delta is left of Volume and both extend left.

## Compile status

- The first NinjaTrader F5 attempt reported CS0019 at the Tick Replay availability guard because `IsTickReplays[0]` is nullable in this NinjaTrader build.
- The guard now uses `IsTickReplays[0] == true`; the corrected source was redeployed and the next F5 result is pending.
- The Working_Suite generated accessor/cache region remains stale until NinjaTrader regenerates it for the two new NinjaScript properties.

## Deployment status

- Targeted deployment completed with `deploy_orca.ps1 -Target OrcaStepProfile`.
- Live destination: `C:\Users\julia\Documents\NinjaTrader 8\bin\Custom\Indicators\OrcaStepProfile.cs`.
- Authored-region parity between Working_Suite and the live copy passed.
- NinjaTrader regenerated the live accessor/cache signature with both `TradeSourceMode` and `ActiveUnmirroredLayout`; this is not being counted as an F5 compile result.
- Authored-region parity was reconfirmed after deploying the nullable Tick Replay compile correction.

## Manual-validation status

- Pending Julian's live NinjaTrader validation.
- Validate historical Mirror Profiles with both mirror arrangements and several zoom levels.
- Validate active `Overlay` and `Side by Side (Both Left)` with Mirror Profiles unchecked.
- Compare Secondary Tick Series with Tick Replay Last Events on otherwise identical charts, with Tick Replay enabled only for the latter.
- Confirm the warning appears and historical profiles remain absent when Tick Replay Last Events is selected without chart Tick Replay.

## Known issues, risks, and follow-up work

- Extremely narrow historical periods necessarily compress both mirrored widths; Delta text may still be visually crowded even though profile bars remain inside the period.
- Tick Replay fidelity depends on provider data. NinjaTrader may substitute inside Bid/Ask values when the historical data lacks them.
- Trades between Bid and Ask still use the existing price-change fallback; equal-price trades that cannot be classified at Bid or Ask contribute zero Delta.
- Existing unrelated uncommitted work in `OrcaStepProfile.cs` remains present and was not reverted.

## Promotion eligibility

- Not eligible for promotion to `Full_Suite` until NinjaTrader F5 succeeds and Julian validates both rendering layouts and both trade-source modes on live charts.
