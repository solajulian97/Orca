# Orca Step Profile Timeframes And Volume Steps

## Objective

Add 5-minute, 10-minute, and 2-hour time steps, and add a volume-based step mode that creates profiles at selectable traded-contract thresholds with daily 6:00 PM or 9:30 AM reset anchors.

## Files Changed

- `Orca Trades/Working_Suite/Indicators/OrcaStepProfile.cs`
- `docs/handoffs/2026-08-07_orca-step-profile_timeframes-volume-steps.md`

## Behavior Added, Changed, Or Removed

- Added 5-minute, 10-minute, and 2-hour interval choices.
- Kept time choices in ascending order: 5m, 10m, 15m, 30m, 1h, 2h, 4h, Daily.
- Added `Step Basis` with `Time` and `Volume Amount` choices.
- Volume mode closes each completed profile at the selected exact contract total.
- A trade larger than the remaining capacity is split across consecutive profiles at the same price and timestamp so completed profiles do not overshoot the selected amount.
- Volume sequences reset daily at either 6:00 PM or 9:30 AM. A partial profile is closed at the reset boundary and a new sequence begins.
- Existing time-boundary calculations, including the 6:00 PM-anchored four-hour schedule, remain unchanged.
- Existing active-profile right-scale rendering and historical period anchoring remain unchanged.

## User-Facing Settings

- Added `Step Basis` (`Time`, `Volume Amount`).
- Added `Step Volume Amount` dropdown values: 1,000; 2,000; 5,000; 10,000; 20,000; 50,000; 100,000; 200,000; 500,000.
- Added `Volume Step Start` (`6:00 PM (New Day)`, `9:30 AM (RTH Open)`).
- `Volume Step Start` controls the daily reset anchor only. It does not filter trades. The existing `RTH Only`, `RTH Start Time`, and `RTH End Time` settings continue to control trade inclusion.
- Default behavior remains time-based at 30 minutes. The default volume amount is 100,000 and the default volume reset anchor is 6:00 PM.

## Secondary Series Added Or Changed

None. The indicator continues to use its existing hidden 1-tick Last series. No Bid, Ask, Second, Volumetric, or custom series was added.

## Tick Replay Implications

No Tick Replay setting or path changed. Volume-step construction uses the same hidden 1-tick series as existing step-profile volume and Delta collection. Historical fidelity remains dependent on the available historical tick data and quote context.

## Historical-Load Implications

- Historical volume steps are rebuilt from the loaded hidden tick series.
- The selected daily reset anchor is applied to historical and realtime ticks identically.
- With `RTH Only` enabled, ticks outside the configured RTH window are excluded before either time or volume step processing.

## Cache Implications

No shared cache was added or changed. Existing per-block POC/value-area cache behavior remains in place.

## Rendering Implications

- No SharpDX drawing, clipping, Z-order, active-profile placement, width, color, opacity, POC, value-area, label, or Delta-rendering code was changed.
- Volume blocks populate the existing `StepBlock` model with logical start/end times and primary-bar start/end indexes.
- If multiple volume thresholds complete inside one primary chart bar, those profiles share that bar's X coordinate and can render very narrowly or overlap at bar-level resolution.

## Performance Implications

- Normal processing remains O(1) per tick.
- An unusually large trade may create multiple completed blocks in one update, proportional to the number of thresholds crossed.
- No calculation, historical rebuild, data access, or new allocation path was added to `OnRender`.

## Tests Performed In NinjaTrader

Not yet performed.

## Source And Simulation Tests

- `git diff --check`: passed.
- Balanced braces and unique-property/reference checks: passed.
- Roslyn syntax parse: zero errors.
- Interval-order simulation: strictly ascending through Daily.
- Anchor tests: reset selection changes exactly at 6:00 PM and 9:30 AM.
- Volume split test: 600 + 500 + 2,200 contracts at a 1,000 threshold produced three completed 1,000-contract profiles and 300 contracts in the active profile, preserving all 3,300 contracts.

## Compile Status

NinjaTrader F5 compile pending. NinjaTrader must regenerate the generated accessor/cache region for the three new NinjaScript properties.

## Deployment Status

Deployed with Orca Trades/Scripts/deploy_orca.ps1 -Target OrcaStepProfile to C:\Users\julia\Documents\NinjaTrader 8\bin\Custom\Indicators\OrcaStepProfile.cs. The Working_Suite and live authored regions match exactly, all three new authored properties are present, and the live file contains exactly one preserved generated region.
## Manual-Validation Status

Pending. Validate all new dropdown entries, 5m/10m/2h boundaries, both reset anchors, RTH-only interaction, volume totals, active-profile updates, historical placement, and scroll/zoom behavior.

## Known Issues, Risks, And Follow-Up Work

- The 9:30 AM reset choice does not automatically exclude overnight volume; enable `RTH Only` when an RTH-only volume sequence is desired.
- Multiple thresholds inside one primary chart bar have bar-level horizontal resolution.
- No existing time, volume-profile, Delta, POC, value-area, rendering, or dynamic aggregation setting was removed.

## Full_Suite Promotion Eligibility

Not eligible until NinjaTrader F5 compilation and Julian's live manual validation are complete.
