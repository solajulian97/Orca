# Statistics After Separator

## Objective and files

Follow-up to spine alignment: place historical statistics on their own profile's side. Changed Working_Suite/Indicators/OrcaStepProfile.cs, tests/OrcaStepProfile.PlatformCheck/Program.cs, and this handoff.

## Behavior

Historical rows now begin four pixels right of their separator, with leading alignment and clipping at their own period end. Active statistics keep trailing alignment on the separate second line. This supersedes the preceding-spine placement in the earlier handoff. No settings or defaults changed.

## Filter investigation

Filtered labels require all three thresholds simultaneously. Minimum bar spacing is distance between chart candles, not profile width. Increasing it hides more labels. Zero row-height and zero bar-spacing thresholds disable both zoom gates; minimum absolute delta 500 then permits values of either sign with magnitude at least 500. Added three actual-production-expression checks for that configuration, including one-pixel rows. No filter logic change was needed. Very dense rows or narrow histogram clipping can still impair readability; hover remains available.

## Data and rendering implications

No secondary series, AddDataSeries, OnMarketData, Calculate, Tick Replay, Playback, historical load, shared cache, or statistics calculation changes. No new SharpDX resources or per-row allocations. Only statistics rectangle/format alignment changed; histogram clipping and active geometry are preserved.

## Validation and promotion

Offline NinjaTrader semantic check passed with zero errors and all fourteen filter cases passed. Targeted deployment succeeded, authored source/live parity passed, and scoped git diff --check passed. Explicit F5 and chart behavior remain separate manual gates. Check separator ownership and clipped narrow periods visually. Full_Suite is untouched and is not eligible for promotion pending Julian's validation. Existing unrelated source edits are preserved; no whole-file commit bundles them.
