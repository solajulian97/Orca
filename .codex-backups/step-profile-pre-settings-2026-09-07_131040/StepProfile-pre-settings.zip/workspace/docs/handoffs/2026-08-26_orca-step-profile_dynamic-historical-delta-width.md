# Orca Step Profile Dynamic Historical Delta Width

## Objective

Allow completed Step Profile delta histograms to scale with horizontal zoom instead of retaining a large fixed pixel width.

## Files changed

- `Orca Trades/Working_Suite/Indicators/OrcaStepProfile.cs`
- `docs/handoffs/2026-08-26_orca-step-profile_dynamic-historical-delta-width.md`

## Behavior added, changed, or removed

- Completed delta profiles can now use a percentage of their own completed step period width.
- Dynamic historical delta width is enabled by default at 10 percent.
- The immediately previous active delta follows this behavior once its period completes and it becomes historical.
- Left-facing historical delta still belongs to and is sized from its own period; it does not depend on the neighboring previous period's width.
- Disabling dynamic historical delta width restores the existing fixed `Historical Delta Width (px)` behavior.
- The active right-edge delta remains fixed by `Active Delta Width (px)` and is otherwise unchanged.

## User-facing settings added, changed, deprecated, or removed

The `Layout` section adds:

- `Dynamic Historical Delta Width` (default on)
- `Historical Delta Fill Percent` (default 10, range 1-100)

`Historical Delta Width (px)` remains available as the fixed-mode fallback.

## Secondary series added or changed

No secondary series were added or changed. Existing trade-source behavior remains unchanged.

## Tick Replay implications

No Tick Replay requirement or behavior changed.

## Historical-load implications

No historical aggregation, block construction, period boundaries, or load behavior changed.

## Cache implications

No profile data cache or shared cache behavior changed.

## Rendering implications

- Historical delta maximum width is calculated as `periodWidth * HistoricalDeltaFillPercent / 100` when enabled.
- The result retains the existing minimum two-pixel guard and cannot exceed its own period width.
- Existing period clipping and left/right mirror arrangement behavior are preserved.
- Active-profile right-edge geometry is unchanged.

## Performance implications

The render loop adds one boolean branch and one constant-time width calculation per visible completed block. No allocations, model mutations, cache reads, synchronization, or profile rebuilds were added to `OnRender`.

## Tests performed in NinjaTrader

Pending F5 compilation and live chart testing.

## Static tests performed

- Roslyn syntax parsing passed with zero errors.
- Opening and closing brace counts match.
- `git diff --check` passed with only the repository line-ending warning.
- Source audit confirmed the enabled default, 10 percent default, own-period width calculation, fixed-width fallback, and unchanged active fixed-width render call.
- The live authored region matches `Working_Suite` with SHA-256 `F2AFA1891F701C1BC8AB1A5C8767CBCB5E6590433DE2D12F8573C0BCCCB01E07`.
- The live file contains one generated-code region and one declaration for each new setting.

## Compile status

Targeted deployment completed with `deploy_orca.ps1 -Target OrcaStepProfile`. NinjaTrader F5 compilation remains pending.

## Manual-validation status

Pending. Validate completed delta widths at normal, compressed, and expanded horizontal zoom with both mirror arrangements, then confirm the active delta remains fixed at the right edge.

## Known issues, risks, and follow-up work

- At extremely compressed zoom, the existing two-pixel minimum remains visible even when 10 percent would round lower.
- Existing unrelated uncommitted Step Profile work was preserved.

## Promotion eligibility

Not eligible for promotion to `Full_Suite` until NinjaTrader compiles and Julian confirms live zoom behavior.
