# Orca Step Profile Historical Mirror Session Anchor

## Objective

Correct the apparent late start of historical mirrored session profiles after the prior clipping fix. Keep the shared Volume/Delta spine exactly on the session separator while retaining both mirrored sides.

## Files changed

- `Orca Trades/Working_Suite/Indicators/OrcaStepProfile.cs`
- `docs/handoffs/2026-08-17_orca-step-profile_historical-mirror-session-anchor.md`

## Behavior added, changed, or removed

- Historical mirrored profiles no longer move their shared spine inward by the left profile's pixel width.
- The shared spine remains at the block's true start coordinate, matching the block separator at 6:00 PM, 3:00 AM, or 9:30 AM in Session mode.
- The historical clip expands left by only the width of the profile assigned to the left side:
  - Delta width for Delta left / Volume right.
  - Volume width for Volume left / Delta right.
- The right-side profile remains constrained by the historical block's end coordinate.
- This supersedes the combined-width/inward-spine geometry documented in `2026-08-17_orca-step-profile_mirror-layout-trade-source.md`.

## User-facing settings

- No settings were added, removed, or renamed.
- Existing `Mirror Profiles` and `Mirror Arrangement` selections control which profile extends left of the session separator.

## Secondary series

- No secondary series were added or changed.
- Trade Source Mode behavior is unchanged.

## Tick Replay implications

- No Tick Replay behavior changed.

## Historical-load implications

- No profile boundaries, timestamps, tick accumulation, or historical rebuilding logic changed.
- The 3:00 AM London separator was already correct; only rendered profile geometry was offset.

## Cache implications

- No cache behavior changed.

## Rendering implications

- Historical mirror rendering now straddles the true block-start separator.
- The SharpDX clip can extend into the preceding chart space for the selected left-side profile, while remaining bounded by the chart panel.
- Value-area and Delta text rendering continue to use the existing mirrored geometry.

## Performance implications

- The change replaces constant-time width arithmetic with simpler constant-time clip arithmetic.
- No allocations, extra render passes, map copies, or data subscriptions were added.

## Tests performed

- `git diff --check` passed for `OrcaStepProfile.cs` (line-ending warning only).
- Static checks confirmed the inward-spine helper was removed, `spineX` equals `startX`, one mirror clip expansion remains, and one generated-code region remains.
- Geometry simulation confirmed:
  - Delta left / Volume right uses Delta `[-deltaWidth, 0]`, separator `0`, and Volume `[0, profileWidth]`.
  - Volume left / Delta right uses Volume `[-profileWidth, 0]`, separator `0`, and Delta `[0, deltaWidth]`.

## Compile status

- NinjaTrader F5 compile is pending after deployment.

## Deployment status

- Targeted deployment completed with `deploy_orca.ps1 -Target OrcaStepProfile`.
- Live destination: `C:\Users\julia\Documents\NinjaTrader 8\bin\Custom\Indicators\OrcaStepProfile.cs`.
- Authored-region parity passed, and the live copy contains both the spine-at-start and mirror clip-expansion logic.

## Manual-validation status

- Pending Julian's chart validation at the 6:00 PM, 3:00 AM, and 9:30 AM session separators.
- Validate both mirror arrangements at multiple horizontal zoom levels.

## Known issues, risks, and follow-up work

- The left mirrored profile intentionally occupies chart space immediately before the session boundary and can visually overlap the preceding session's candles or profile.
- Extremely wide configured historical profiles may create more overlap, but the chart-panel clip prevents drawing outside the panel.
- Correction after hourly-chart review: the separator itself could resolve to the preceding bar because the block-start index was not deterministically mapped to close-stamped primary bars. That separate indexing defect is addressed in `2026-08-17_orca-step-profile_close-stamped-boundary-index.md`.

## Promotion eligibility

- Not eligible for promotion to `Full_Suite` until F5 succeeds and Julian confirms the historical profile spine aligns with each session separator.
