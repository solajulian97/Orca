# Orca Step Profile Independent Active Mirror Arrangement

## Objective

Allow the active Step Profile to use a different mirrored Volume/Delta arrangement from completed historical profiles.

## Files changed

- `Orca Trades/Working_Suite/Indicators/OrcaStepProfile.cs`
- `docs/handoffs/2026-08-18_orca-step-profile_independent-active-mirror-arrangement.md`

## Behavior added, changed, or removed

- Historical and active mirrored profiles now receive their own arrangement value at render time.
- The existing `Mirror Arrangement` setting is now labeled `Historical Mirror Arrangement` and continues to control completed profiles.
- A new `Active Mirror Arrangement` controls only the active right-edge profile when `Mirror Profiles` is enabled.
- The requested combination is supported:
  - Historical: `DeltaLeft_VolumeRight`.
  - Active: `VolumeLeft_DeltaRight`.
- Existing chart templates preserve their prior behavior because the new active setting defaults to `DeltaLeft_VolumeRight`, matching the historical default.

## User-facing settings added, changed, deprecated, or removed

- Renamed displayed setting: `Mirror Arrangement` to `Historical Mirror Arrangement`.
- Added `Active Mirror Arrangement` under `Layout`.
- `Active Unmirrored Layout` and `Draw Behind Candles` remain available and apply as before when `Mirror Profiles` is disabled.

## Secondary series added or changed

- No secondary series were added or changed.

## Tick Replay implications

- No Tick Replay behavior changed.

## Historical-load implications

- No historical data, boundary, aggregation, or rebuild behavior changed.

## Cache implications

- No cache behavior changed.

## Rendering implications

- The Volume and Delta render functions now receive the selected arrangement explicitly instead of reading one shared setting.
- Historical profiles use `Historical Mirror Arrangement`; the active profile uses `Active Mirror Arrangement`.
- For the requested pairing, historical Volume extends right of its spine while historical Delta extends left; active Volume extends left of the active spine and active Delta occupies the right-side segment beside it.

## Performance implications

- The change passes an enum value through existing render calls.
- No allocations, profile rebuilds, extra passes, synchronization, or data subscriptions were added.

## Tests performed in NinjaTrader

- Pending Julian's F5 compile and chart validation.

## Static tests performed

- `git diff --check` passed for `OrcaStepProfile.cs`; only the existing line-ending conversion warning was reported.
- Brace-count check passed.
- Render-call audit confirmed both historical calls receive `MirrorArrangement` and both active calls receive `ActiveMirrorArrangement`.
- Geometry check for a 150 px active Volume width and 60 px active Delta width confirmed `VolumeLeft_DeltaRight` produces Volume `[290, 440]` and Delta `[440, 500]` at an active spine of `500`.

## Compile status

- NinjaTrader F5 compile pending after deployment.
- The deployed live NinjaScript accessor/cache region includes `ActiveMirrorArrangement`; this does not replace an explicit F5 result.

## Deployment status

- Targeted deployment completed with `deploy_orca.ps1 -Target OrcaStepProfile`.
- Live destination: `C:\Users\julia\Documents\NinjaTrader 8\bin\Custom\Indicators\OrcaStepProfile.cs`.
- Normalized authored-region parity between `Working_Suite` and the live copy passed.

## Manual-validation status

- Pending validation with `Mirror Profiles` enabled.
- Set `Historical Mirror Arrangement` to `DeltaLeft_VolumeRight` and `Active Mirror Arrangement` to `VolumeLeft_DeltaRight`.
- Confirm historical Volume faces right and active Volume faces left, with Delta immediately to its right.

## Known issues, risks, and follow-up work

- The setting is intentionally ignored when `Mirror Profiles` is disabled because active unmirrored layout has separate behavior.
- Existing uncommitted work in `OrcaStepProfile.cs` remains preserved.

## Promotion eligibility

- Not eligible for promotion to `Full_Suite` until NinjaTrader compiles and Julian confirms the requested live layout.
